﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tlw.ZPG.Domain.Models.Bid;
using Tlw.ZPG.Infrastructure.Domain.Events;

namespace Tlw.ZPG.Domain.Models.Bid.Events
{
    public abstract class AccountEventBase : IDomainEvent
    {
        public Account Account { get; set; }
    }
}
