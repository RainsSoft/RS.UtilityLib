﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Teleware.ZPG.Client
{
    public enum NotifyBoxIcon
    {
        Success,
        Fail,
        Info,
    }
}
