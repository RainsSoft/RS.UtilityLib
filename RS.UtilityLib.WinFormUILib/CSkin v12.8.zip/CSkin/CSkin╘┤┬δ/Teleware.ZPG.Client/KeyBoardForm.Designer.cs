using CCWin.SkinControl;
namespace Teleware.ZPG.Client
{
    partial class KeyBoardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KeyBoardForm));
            this.toolShow = new System.Windows.Forms.ToolTip(this.components);
            this.btnhx2 = new CCWin.SkinControl.SkinButton();
            this.btndh = new CCWin.SkinControl.SkinButton();
            this.btnjh = new CCWin.SkinControl.SkinButton();
            this.btnhx = new CCWin.SkinControl.SkinButton();
            this.btnd4 = new CCWin.SkinControl.SkinButton();
            this.btnd3 = new CCWin.SkinControl.SkinButton();
            this.btnd2 = new CCWin.SkinControl.SkinButton();
            this.btnMh = new CCWin.SkinControl.SkinButton();
            this.btnKh2 = new CCWin.SkinControl.SkinButton();
            this.btnKh1 = new CCWin.SkinControl.SkinButton();
            this.btny = new CCWin.SkinControl.SkinButton();
            this.btnx = new CCWin.SkinControl.SkinButton();
            this.btnw = new CCWin.SkinControl.SkinButton();
            this.btnv = new CCWin.SkinControl.SkinButton();
            this.btnu = new CCWin.SkinControl.SkinButton();
            this.btnt = new CCWin.SkinControl.SkinButton();
            this.btns = new CCWin.SkinControl.SkinButton();
            this.btnr = new CCWin.SkinControl.SkinButton();
            this.btnq = new CCWin.SkinControl.SkinButton();
            this.btnp = new CCWin.SkinControl.SkinButton();
            this.btno = new CCWin.SkinControl.SkinButton();
            this.btnn = new CCWin.SkinControl.SkinButton();
            this.btnz = new CCWin.SkinControl.SkinButton();
            this.btna = new CCWin.SkinControl.SkinButton();
            this.btnm = new CCWin.SkinControl.SkinButton();
            this.btnl = new CCWin.SkinControl.SkinButton();
            this.btnk = new CCWin.SkinControl.SkinButton();
            this.btnj = new CCWin.SkinControl.SkinButton();
            this.btni = new CCWin.SkinControl.SkinButton();
            this.btnh = new CCWin.SkinControl.SkinButton();
            this.btng = new CCWin.SkinControl.SkinButton();
            this.btnf = new CCWin.SkinControl.SkinButton();
            this.btne = new CCWin.SkinControl.SkinButton();
            this.btnd = new CCWin.SkinControl.SkinButton();
            this.btnc = new CCWin.SkinControl.SkinButton();
            this.btnb = new CCWin.SkinControl.SkinButton();
            this.btn6 = new CCWin.SkinControl.SkinButton();
            this.btn5 = new CCWin.SkinControl.SkinButton();
            this.btn4 = new CCWin.SkinControl.SkinButton();
            this.btn3 = new CCWin.SkinControl.SkinButton();
            this.btn2 = new CCWin.SkinControl.SkinButton();
            this.btn1 = new CCWin.SkinControl.SkinButton();
            this.btnd1 = new CCWin.SkinControl.SkinButton();
            this.btn0 = new CCWin.SkinControl.SkinButton();
            this.btn9 = new CCWin.SkinControl.SkinButton();
            this.btn8 = new CCWin.SkinControl.SkinButton();
            this.btn7 = new CCWin.SkinControl.SkinButton();
            this.btnShift = new CCWin.SkinControl.SkinButton();
            this.btnClose = new CCWin.SkinControl.SkinButton();
            this.btnCapsLock = new CCWin.SkinControl.SkinButton();
            this.btnDelet = new CCWin.SkinControl.SkinButton();
            this.SuspendLayout();
            // 
            // toolShow
            // 
            this.toolShow.BackColor = System.Drawing.Color.White;
            // 
            // btnhx2
            // 
            this.btnhx2.BackColor = System.Drawing.Color.White;
            this.btnhx2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnhx2.BackgroundImage")));
            this.btnhx2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnhx2.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnhx2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnhx2.DownBack = ((System.Drawing.Image)(resources.GetObject("btnhx2.DownBack")));
            this.btnhx2.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnhx2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnhx2.Location = new System.Drawing.Point(268, 30);
            this.btnhx2.Margin = new System.Windows.Forms.Padding(0);
            this.btnhx2.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnhx2.MouseBack")));
            this.btnhx2.Name = "btnhx2";
            this.btnhx2.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnhx2.NormlBack")));
            this.btnhx2.Radius = 4;
            this.btnhx2.Size = new System.Drawing.Size(24, 24);
            this.btnhx2.TabIndex = 50;
            this.btnhx2.Tag = "1|\\";
            this.btnhx2.Text = "\\";
            this.btnhx2.UseMnemonic = false;
            this.btnhx2.UseVisualStyleBackColor = false;
            this.btnhx2.Click += new System.EventHandler(this.btn_Click);
            // 
            // btndh
            // 
            this.btndh.BackColor = System.Drawing.Color.White;
            this.btndh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btndh.BackgroundImage")));
            this.btndh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btndh.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btndh.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btndh.DownBack = ((System.Drawing.Image)(resources.GetObject("btndh.DownBack")));
            this.btndh.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btndh.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btndh.Location = new System.Drawing.Point(243, 30);
            this.btndh.Margin = new System.Windows.Forms.Padding(0);
            this.btndh.MouseBack = ((System.Drawing.Image)(resources.GetObject("btndh.MouseBack")));
            this.btndh.Name = "btndh";
            this.btndh.NormlBack = ((System.Drawing.Image)(resources.GetObject("btndh.NormlBack")));
            this.btndh.Radius = 4;
            this.btndh.Size = new System.Drawing.Size(24, 24);
            this.btndh.TabIndex = 49;
            this.btndh.Tag = "1+=";
            this.btndh.Text = "=";
            this.btndh.UseMnemonic = false;
            this.btndh.UseVisualStyleBackColor = false;
            this.btndh.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnjh
            // 
            this.btnjh.BackColor = System.Drawing.Color.White;
            this.btnjh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnjh.BackgroundImage")));
            this.btnjh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnjh.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnjh.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnjh.DownBack = ((System.Drawing.Image)(resources.GetObject("btnjh.DownBack")));
            this.btnjh.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnjh.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnjh.Location = new System.Drawing.Point(218, 30);
            this.btnjh.Margin = new System.Windows.Forms.Padding(0);
            this.btnjh.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnjh.MouseBack")));
            this.btnjh.Name = "btnjh";
            this.btnjh.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnjh.NormlBack")));
            this.btnjh.Radius = 4;
            this.btnjh.Size = new System.Drawing.Size(24, 24);
            this.btnjh.TabIndex = 48;
            this.btnjh.Tag = "1_-";
            this.btnjh.Text = "-";
            this.btnjh.UseMnemonic = false;
            this.btnjh.UseVisualStyleBackColor = false;
            this.btnjh.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnhx
            // 
            this.btnhx.BackColor = System.Drawing.Color.White;
            this.btnhx.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnhx.BackgroundImage")));
            this.btnhx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnhx.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnhx.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnhx.DownBack = ((System.Drawing.Image)(resources.GetObject("btnhx.DownBack")));
            this.btnhx.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnhx.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnhx.Location = new System.Drawing.Point(193, 30);
            this.btnhx.Margin = new System.Windows.Forms.Padding(0);
            this.btnhx.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnhx.MouseBack")));
            this.btnhx.Name = "btnhx";
            this.btnhx.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnhx.NormlBack")));
            this.btnhx.Radius = 4;
            this.btnhx.Size = new System.Drawing.Size(24, 24);
            this.btnhx.TabIndex = 47;
            this.btnhx.Tag = "1?/";
            this.btnhx.Text = "/";
            this.btnhx.UseMnemonic = false;
            this.btnhx.UseVisualStyleBackColor = false;
            this.btnhx.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnd4
            // 
            this.btnd4.BackColor = System.Drawing.Color.White;
            this.btnd4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnd4.BackgroundImage")));
            this.btnd4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnd4.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnd4.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnd4.DownBack = ((System.Drawing.Image)(resources.GetObject("btnd4.DownBack")));
            this.btnd4.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnd4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnd4.Location = new System.Drawing.Point(168, 30);
            this.btnd4.Margin = new System.Windows.Forms.Padding(0);
            this.btnd4.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnd4.MouseBack")));
            this.btnd4.Name = "btnd4";
            this.btnd4.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnd4.NormlBack")));
            this.btnd4.Radius = 4;
            this.btnd4.Size = new System.Drawing.Size(24, 24);
            this.btnd4.TabIndex = 46;
            this.btnd4.Tag = "1>.";
            this.btnd4.Text = ".";
            this.btnd4.UseMnemonic = false;
            this.btnd4.UseVisualStyleBackColor = false;
            this.btnd4.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnd3
            // 
            this.btnd3.BackColor = System.Drawing.Color.White;
            this.btnd3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnd3.BackgroundImage")));
            this.btnd3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnd3.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnd3.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnd3.DownBack = ((System.Drawing.Image)(resources.GetObject("btnd3.DownBack")));
            this.btnd3.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnd3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnd3.Location = new System.Drawing.Point(143, 30);
            this.btnd3.Margin = new System.Windows.Forms.Padding(0);
            this.btnd3.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnd3.MouseBack")));
            this.btnd3.Name = "btnd3";
            this.btnd3.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnd3.NormlBack")));
            this.btnd3.Radius = 4;
            this.btnd3.Size = new System.Drawing.Size(24, 24);
            this.btnd3.TabIndex = 45;
            this.btnd3.Tag = "1<,";
            this.btnd3.Text = ",";
            this.btnd3.UseMnemonic = false;
            this.btnd3.UseVisualStyleBackColor = false;
            this.btnd3.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnd2
            // 
            this.btnd2.BackColor = System.Drawing.Color.White;
            this.btnd2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnd2.BackgroundImage")));
            this.btnd2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnd2.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnd2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnd2.DownBack = ((System.Drawing.Image)(resources.GetObject("btnd2.DownBack")));
            this.btnd2.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnd2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnd2.Location = new System.Drawing.Point(118, 30);
            this.btnd2.Margin = new System.Windows.Forms.Padding(0);
            this.btnd2.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnd2.MouseBack")));
            this.btnd2.Name = "btnd2";
            this.btnd2.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnd2.NormlBack")));
            this.btnd2.Radius = 4;
            this.btnd2.Size = new System.Drawing.Size(24, 24);
            this.btnd2.TabIndex = 44;
            this.btnd2.Tag = "1\"\'";
            this.btnd2.Text = "\'";
            this.btnd2.UseMnemonic = false;
            this.btnd2.UseVisualStyleBackColor = false;
            this.btnd2.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnMh
            // 
            this.btnMh.BackColor = System.Drawing.Color.White;
            this.btnMh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMh.BackgroundImage")));
            this.btnMh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnMh.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnMh.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnMh.DownBack = ((System.Drawing.Image)(resources.GetObject("btnMh.DownBack")));
            this.btnMh.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnMh.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnMh.Location = new System.Drawing.Point(93, 30);
            this.btnMh.Margin = new System.Windows.Forms.Padding(0);
            this.btnMh.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnMh.MouseBack")));
            this.btnMh.Name = "btnMh";
            this.btnMh.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnMh.NormlBack")));
            this.btnMh.Radius = 4;
            this.btnMh.Size = new System.Drawing.Size(24, 24);
            this.btnMh.TabIndex = 43;
            this.btnMh.Tag = "1:;";
            this.btnMh.Text = ";";
            this.btnMh.UseMnemonic = false;
            this.btnMh.UseVisualStyleBackColor = false;
            this.btnMh.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnKh2
            // 
            this.btnKh2.BackColor = System.Drawing.Color.White;
            this.btnKh2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKh2.BackgroundImage")));
            this.btnKh2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnKh2.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnKh2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnKh2.DownBack = ((System.Drawing.Image)(resources.GetObject("btnKh2.DownBack")));
            this.btnKh2.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnKh2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnKh2.Location = new System.Drawing.Point(68, 30);
            this.btnKh2.Margin = new System.Windows.Forms.Padding(0);
            this.btnKh2.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnKh2.MouseBack")));
            this.btnKh2.Name = "btnKh2";
            this.btnKh2.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnKh2.NormlBack")));
            this.btnKh2.Radius = 4;
            this.btnKh2.Size = new System.Drawing.Size(24, 24);
            this.btnKh2.TabIndex = 42;
            this.btnKh2.Tag = "1}]";
            this.btnKh2.Text = "]";
            this.btnKh2.UseMnemonic = false;
            this.btnKh2.UseVisualStyleBackColor = false;
            this.btnKh2.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnKh1
            // 
            this.btnKh1.BackColor = System.Drawing.Color.White;
            this.btnKh1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKh1.BackgroundImage")));
            this.btnKh1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnKh1.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnKh1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnKh1.DownBack = ((System.Drawing.Image)(resources.GetObject("btnKh1.DownBack")));
            this.btnKh1.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnKh1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnKh1.Location = new System.Drawing.Point(43, 30);
            this.btnKh1.Margin = new System.Windows.Forms.Padding(0);
            this.btnKh1.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnKh1.MouseBack")));
            this.btnKh1.Name = "btnKh1";
            this.btnKh1.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnKh1.NormlBack")));
            this.btnKh1.Radius = 4;
            this.btnKh1.Size = new System.Drawing.Size(24, 24);
            this.btnKh1.TabIndex = 41;
            this.btnKh1.Tag = "1{[";
            this.btnKh1.Text = "[";
            this.btnKh1.UseMnemonic = false;
            this.btnKh1.UseVisualStyleBackColor = false;
            this.btnKh1.Click += new System.EventHandler(this.btn_Click);
            // 
            // btny
            // 
            this.btny.BackColor = System.Drawing.Color.White;
            this.btny.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btny.BackgroundImage")));
            this.btny.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btny.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btny.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btny.DownBack = ((System.Drawing.Image)(resources.GetObject("btny.DownBack")));
            this.btny.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btny.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.btny.Location = new System.Drawing.Point(323, 82);
            this.btny.Margin = new System.Windows.Forms.Padding(0);
            this.btny.MouseBack = ((System.Drawing.Image)(resources.GetObject("btny.MouseBack")));
            this.btny.Name = "btny";
            this.btny.NormlBack = ((System.Drawing.Image)(resources.GetObject("btny.NormlBack")));
            this.btny.Radius = 6;
            this.btny.Size = new System.Drawing.Size(25, 24);
            this.btny.TabIndex = 40;
            this.btny.Tag = "2";
            this.btny.Text = "y";
            this.btny.UseMnemonic = false;
            this.btny.UseVisualStyleBackColor = false;
            this.btny.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnx
            // 
            this.btnx.BackColor = System.Drawing.Color.White;
            this.btnx.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnx.BackgroundImage")));
            this.btnx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnx.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnx.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnx.DownBack = ((System.Drawing.Image)(resources.GetObject("btnx.DownBack")));
            this.btnx.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnx.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnx.Location = new System.Drawing.Point(297, 82);
            this.btnx.Margin = new System.Windows.Forms.Padding(0);
            this.btnx.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnx.MouseBack")));
            this.btnx.Name = "btnx";
            this.btnx.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnx.NormlBack")));
            this.btnx.Radius = 4;
            this.btnx.Size = new System.Drawing.Size(25, 24);
            this.btnx.TabIndex = 39;
            this.btnx.Tag = "2";
            this.btnx.Text = "x";
            this.btnx.UseMnemonic = false;
            this.btnx.UseVisualStyleBackColor = false;
            this.btnx.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnw
            // 
            this.btnw.BackColor = System.Drawing.Color.White;
            this.btnw.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnw.BackgroundImage")));
            this.btnw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnw.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnw.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnw.DownBack = ((System.Drawing.Image)(resources.GetObject("btnw.DownBack")));
            this.btnw.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnw.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnw.Location = new System.Drawing.Point(271, 82);
            this.btnw.Margin = new System.Windows.Forms.Padding(0);
            this.btnw.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnw.MouseBack")));
            this.btnw.Name = "btnw";
            this.btnw.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnw.NormlBack")));
            this.btnw.Radius = 4;
            this.btnw.Size = new System.Drawing.Size(25, 24);
            this.btnw.TabIndex = 38;
            this.btnw.Tag = "2";
            this.btnw.Text = "w";
            this.btnw.UseMnemonic = false;
            this.btnw.UseVisualStyleBackColor = false;
            this.btnw.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnv
            // 
            this.btnv.BackColor = System.Drawing.Color.White;
            this.btnv.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnv.BackgroundImage")));
            this.btnv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnv.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnv.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnv.DownBack = ((System.Drawing.Image)(resources.GetObject("btnv.DownBack")));
            this.btnv.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnv.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnv.Location = new System.Drawing.Point(245, 82);
            this.btnv.Margin = new System.Windows.Forms.Padding(0);
            this.btnv.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnv.MouseBack")));
            this.btnv.Name = "btnv";
            this.btnv.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnv.NormlBack")));
            this.btnv.Radius = 4;
            this.btnv.Size = new System.Drawing.Size(25, 24);
            this.btnv.TabIndex = 37;
            this.btnv.Tag = "2";
            this.btnv.Text = "v";
            this.btnv.UseMnemonic = false;
            this.btnv.UseVisualStyleBackColor = false;
            this.btnv.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnu
            // 
            this.btnu.BackColor = System.Drawing.Color.White;
            this.btnu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnu.BackgroundImage")));
            this.btnu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnu.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnu.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnu.DownBack = ((System.Drawing.Image)(resources.GetObject("btnu.DownBack")));
            this.btnu.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnu.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnu.Location = new System.Drawing.Point(219, 82);
            this.btnu.Margin = new System.Windows.Forms.Padding(0);
            this.btnu.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnu.MouseBack")));
            this.btnu.Name = "btnu";
            this.btnu.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnu.NormlBack")));
            this.btnu.Radius = 4;
            this.btnu.Size = new System.Drawing.Size(25, 24);
            this.btnu.TabIndex = 36;
            this.btnu.Tag = "2";
            this.btnu.Text = "u";
            this.btnu.UseMnemonic = false;
            this.btnu.UseVisualStyleBackColor = false;
            this.btnu.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnt
            // 
            this.btnt.BackColor = System.Drawing.Color.White;
            this.btnt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnt.BackgroundImage")));
            this.btnt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnt.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnt.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnt.DownBack = ((System.Drawing.Image)(resources.GetObject("btnt.DownBack")));
            this.btnt.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnt.Location = new System.Drawing.Point(193, 82);
            this.btnt.Margin = new System.Windows.Forms.Padding(0);
            this.btnt.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnt.MouseBack")));
            this.btnt.Name = "btnt";
            this.btnt.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnt.NormlBack")));
            this.btnt.Radius = 4;
            this.btnt.Size = new System.Drawing.Size(25, 24);
            this.btnt.TabIndex = 35;
            this.btnt.Tag = "2";
            this.btnt.Text = "t";
            this.btnt.UseMnemonic = false;
            this.btnt.UseVisualStyleBackColor = false;
            this.btnt.Click += new System.EventHandler(this.btn_Click);
            // 
            // btns
            // 
            this.btns.BackColor = System.Drawing.Color.White;
            this.btns.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btns.BackgroundImage")));
            this.btns.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btns.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btns.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btns.DownBack = ((System.Drawing.Image)(resources.GetObject("btns.DownBack")));
            this.btns.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btns.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btns.Location = new System.Drawing.Point(167, 82);
            this.btns.Margin = new System.Windows.Forms.Padding(0);
            this.btns.MouseBack = ((System.Drawing.Image)(resources.GetObject("btns.MouseBack")));
            this.btns.Name = "btns";
            this.btns.NormlBack = ((System.Drawing.Image)(resources.GetObject("btns.NormlBack")));
            this.btns.Radius = 4;
            this.btns.Size = new System.Drawing.Size(25, 24);
            this.btns.TabIndex = 34;
            this.btns.Tag = "2";
            this.btns.Text = "s";
            this.btns.UseMnemonic = false;
            this.btns.UseVisualStyleBackColor = false;
            this.btns.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnr
            // 
            this.btnr.BackColor = System.Drawing.Color.White;
            this.btnr.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnr.BackgroundImage")));
            this.btnr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnr.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnr.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnr.DownBack = ((System.Drawing.Image)(resources.GetObject("btnr.DownBack")));
            this.btnr.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnr.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnr.Location = new System.Drawing.Point(141, 82);
            this.btnr.Margin = new System.Windows.Forms.Padding(0);
            this.btnr.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnr.MouseBack")));
            this.btnr.Name = "btnr";
            this.btnr.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnr.NormlBack")));
            this.btnr.Radius = 4;
            this.btnr.Size = new System.Drawing.Size(25, 24);
            this.btnr.TabIndex = 33;
            this.btnr.Tag = "2";
            this.btnr.Text = "r";
            this.btnr.UseMnemonic = false;
            this.btnr.UseVisualStyleBackColor = false;
            this.btnr.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnq
            // 
            this.btnq.BackColor = System.Drawing.Color.White;
            this.btnq.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnq.BackgroundImage")));
            this.btnq.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnq.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnq.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnq.DownBack = ((System.Drawing.Image)(resources.GetObject("btnq.DownBack")));
            this.btnq.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnq.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnq.Location = new System.Drawing.Point(115, 82);
            this.btnq.Margin = new System.Windows.Forms.Padding(0);
            this.btnq.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnq.MouseBack")));
            this.btnq.Name = "btnq";
            this.btnq.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnq.NormlBack")));
            this.btnq.Radius = 4;
            this.btnq.Size = new System.Drawing.Size(25, 24);
            this.btnq.TabIndex = 32;
            this.btnq.Tag = "2";
            this.btnq.Text = "q";
            this.btnq.UseMnemonic = false;
            this.btnq.UseVisualStyleBackColor = false;
            this.btnq.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnp
            // 
            this.btnp.BackColor = System.Drawing.Color.White;
            this.btnp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnp.BackgroundImage")));
            this.btnp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnp.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnp.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnp.DownBack = ((System.Drawing.Image)(resources.GetObject("btnp.DownBack")));
            this.btnp.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnp.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnp.Location = new System.Drawing.Point(89, 82);
            this.btnp.Margin = new System.Windows.Forms.Padding(0);
            this.btnp.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnp.MouseBack")));
            this.btnp.Name = "btnp";
            this.btnp.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnp.NormlBack")));
            this.btnp.Radius = 4;
            this.btnp.Size = new System.Drawing.Size(25, 24);
            this.btnp.TabIndex = 31;
            this.btnp.Tag = "2";
            this.btnp.Text = "p";
            this.btnp.UseMnemonic = false;
            this.btnp.UseVisualStyleBackColor = false;
            this.btnp.Click += new System.EventHandler(this.btn_Click);
            // 
            // btno
            // 
            this.btno.BackColor = System.Drawing.Color.White;
            this.btno.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btno.BackgroundImage")));
            this.btno.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btno.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btno.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btno.DownBack = ((System.Drawing.Image)(resources.GetObject("btno.DownBack")));
            this.btno.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btno.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btno.Location = new System.Drawing.Point(63, 82);
            this.btno.Margin = new System.Windows.Forms.Padding(0);
            this.btno.MouseBack = ((System.Drawing.Image)(resources.GetObject("btno.MouseBack")));
            this.btno.Name = "btno";
            this.btno.NormlBack = ((System.Drawing.Image)(resources.GetObject("btno.NormlBack")));
            this.btno.Radius = 4;
            this.btno.Size = new System.Drawing.Size(25, 24);
            this.btno.TabIndex = 30;
            this.btno.Tag = "2";
            this.btno.Text = "o";
            this.btno.UseMnemonic = false;
            this.btno.UseVisualStyleBackColor = false;
            this.btno.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnn
            // 
            this.btnn.BackColor = System.Drawing.Color.White;
            this.btnn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnn.BackgroundImage")));
            this.btnn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnn.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnn.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnn.DownBack = ((System.Drawing.Image)(resources.GetObject("btnn.DownBack")));
            this.btnn.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnn.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnn.Location = new System.Drawing.Point(37, 82);
            this.btnn.Margin = new System.Windows.Forms.Padding(0);
            this.btnn.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnn.MouseBack")));
            this.btnn.Name = "btnn";
            this.btnn.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnn.NormlBack")));
            this.btnn.Radius = 4;
            this.btnn.Size = new System.Drawing.Size(25, 24);
            this.btnn.TabIndex = 29;
            this.btnn.Tag = "2";
            this.btnn.Text = "n";
            this.btnn.UseMnemonic = false;
            this.btnn.UseVisualStyleBackColor = false;
            this.btnn.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnz
            // 
            this.btnz.BackColor = System.Drawing.Color.White;
            this.btnz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnz.BackgroundImage")));
            this.btnz.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnz.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnz.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnz.DownBack = ((System.Drawing.Image)(resources.GetObject("btnz.DownBack")));
            this.btnz.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnz.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnz.Location = new System.Drawing.Point(11, 82);
            this.btnz.Margin = new System.Windows.Forms.Padding(0);
            this.btnz.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnz.MouseBack")));
            this.btnz.Name = "btnz";
            this.btnz.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnz.NormlBack")));
            this.btnz.Radius = 4;
            this.btnz.Size = new System.Drawing.Size(25, 24);
            this.btnz.TabIndex = 28;
            this.btnz.Tag = "2";
            this.btnz.Text = "z";
            this.btnz.UseMnemonic = false;
            this.btnz.UseVisualStyleBackColor = false;
            this.btnz.Click += new System.EventHandler(this.btn_Click);
            // 
            // btna
            // 
            this.btna.BackColor = System.Drawing.Color.White;
            this.btna.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btna.BackgroundImage")));
            this.btna.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btna.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btna.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btna.DownBack = ((System.Drawing.Image)(resources.GetObject("btna.DownBack")));
            this.btna.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btna.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btna.Location = new System.Drawing.Point(323, 56);
            this.btna.Margin = new System.Windows.Forms.Padding(0);
            this.btna.MouseBack = ((System.Drawing.Image)(resources.GetObject("btna.MouseBack")));
            this.btna.Name = "btna";
            this.btna.NormlBack = ((System.Drawing.Image)(resources.GetObject("btna.NormlBack")));
            this.btna.Radius = 4;
            this.btna.Size = new System.Drawing.Size(25, 24);
            this.btna.TabIndex = 27;
            this.btna.Tag = "2";
            this.btna.Text = "a";
            this.btna.UseMnemonic = false;
            this.btna.UseVisualStyleBackColor = false;
            this.btna.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnm
            // 
            this.btnm.BackColor = System.Drawing.Color.White;
            this.btnm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnm.BackgroundImage")));
            this.btnm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnm.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnm.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnm.DownBack = ((System.Drawing.Image)(resources.GetObject("btnm.DownBack")));
            this.btnm.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnm.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnm.Location = new System.Drawing.Point(297, 56);
            this.btnm.Margin = new System.Windows.Forms.Padding(0);
            this.btnm.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnm.MouseBack")));
            this.btnm.Name = "btnm";
            this.btnm.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnm.NormlBack")));
            this.btnm.Radius = 4;
            this.btnm.Size = new System.Drawing.Size(25, 24);
            this.btnm.TabIndex = 26;
            this.btnm.Tag = "2";
            this.btnm.Text = "m";
            this.btnm.UseMnemonic = false;
            this.btnm.UseVisualStyleBackColor = false;
            this.btnm.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnl
            // 
            this.btnl.BackColor = System.Drawing.Color.White;
            this.btnl.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnl.BackgroundImage")));
            this.btnl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnl.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnl.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnl.DownBack = ((System.Drawing.Image)(resources.GetObject("btnl.DownBack")));
            this.btnl.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnl.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnl.Location = new System.Drawing.Point(271, 56);
            this.btnl.Margin = new System.Windows.Forms.Padding(0);
            this.btnl.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnl.MouseBack")));
            this.btnl.Name = "btnl";
            this.btnl.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnl.NormlBack")));
            this.btnl.Radius = 4;
            this.btnl.Size = new System.Drawing.Size(25, 24);
            this.btnl.TabIndex = 25;
            this.btnl.Tag = "2";
            this.btnl.Text = "l";
            this.btnl.UseMnemonic = false;
            this.btnl.UseVisualStyleBackColor = false;
            this.btnl.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnk
            // 
            this.btnk.BackColor = System.Drawing.Color.White;
            this.btnk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnk.BackgroundImage")));
            this.btnk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnk.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnk.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnk.DownBack = ((System.Drawing.Image)(resources.GetObject("btnk.DownBack")));
            this.btnk.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnk.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnk.Location = new System.Drawing.Point(245, 56);
            this.btnk.Margin = new System.Windows.Forms.Padding(0);
            this.btnk.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnk.MouseBack")));
            this.btnk.Name = "btnk";
            this.btnk.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnk.NormlBack")));
            this.btnk.Radius = 4;
            this.btnk.Size = new System.Drawing.Size(25, 24);
            this.btnk.TabIndex = 24;
            this.btnk.Tag = "2";
            this.btnk.Text = "k";
            this.btnk.UseMnemonic = false;
            this.btnk.UseVisualStyleBackColor = false;
            this.btnk.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnj
            // 
            this.btnj.BackColor = System.Drawing.Color.White;
            this.btnj.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnj.BackgroundImage")));
            this.btnj.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnj.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnj.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnj.DownBack = ((System.Drawing.Image)(resources.GetObject("btnj.DownBack")));
            this.btnj.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnj.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnj.Location = new System.Drawing.Point(219, 56);
            this.btnj.Margin = new System.Windows.Forms.Padding(0);
            this.btnj.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnj.MouseBack")));
            this.btnj.Name = "btnj";
            this.btnj.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnj.NormlBack")));
            this.btnj.Radius = 4;
            this.btnj.Size = new System.Drawing.Size(25, 24);
            this.btnj.TabIndex = 23;
            this.btnj.Tag = "2";
            this.btnj.Text = "j";
            this.btnj.UseMnemonic = false;
            this.btnj.UseVisualStyleBackColor = false;
            this.btnj.Click += new System.EventHandler(this.btn_Click);
            // 
            // btni
            // 
            this.btni.BackColor = System.Drawing.Color.White;
            this.btni.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btni.BackgroundImage")));
            this.btni.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btni.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btni.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btni.DownBack = ((System.Drawing.Image)(resources.GetObject("btni.DownBack")));
            this.btni.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btni.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btni.Location = new System.Drawing.Point(193, 56);
            this.btni.Margin = new System.Windows.Forms.Padding(0);
            this.btni.MouseBack = ((System.Drawing.Image)(resources.GetObject("btni.MouseBack")));
            this.btni.Name = "btni";
            this.btni.NormlBack = ((System.Drawing.Image)(resources.GetObject("btni.NormlBack")));
            this.btni.Radius = 4;
            this.btni.Size = new System.Drawing.Size(25, 24);
            this.btni.TabIndex = 22;
            this.btni.Tag = "2";
            this.btni.Text = "i";
            this.btni.UseMnemonic = false;
            this.btni.UseVisualStyleBackColor = false;
            this.btni.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnh
            // 
            this.btnh.BackColor = System.Drawing.Color.White;
            this.btnh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnh.BackgroundImage")));
            this.btnh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnh.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnh.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnh.DownBack = ((System.Drawing.Image)(resources.GetObject("btnh.DownBack")));
            this.btnh.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnh.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnh.Location = new System.Drawing.Point(167, 56);
            this.btnh.Margin = new System.Windows.Forms.Padding(0);
            this.btnh.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnh.MouseBack")));
            this.btnh.Name = "btnh";
            this.btnh.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnh.NormlBack")));
            this.btnh.Radius = 4;
            this.btnh.Size = new System.Drawing.Size(25, 24);
            this.btnh.TabIndex = 21;
            this.btnh.Tag = "2";
            this.btnh.Text = "h";
            this.btnh.UseMnemonic = false;
            this.btnh.UseVisualStyleBackColor = false;
            this.btnh.Click += new System.EventHandler(this.btn_Click);
            // 
            // btng
            // 
            this.btng.BackColor = System.Drawing.Color.White;
            this.btng.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btng.BackgroundImage")));
            this.btng.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btng.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btng.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btng.DownBack = ((System.Drawing.Image)(resources.GetObject("btng.DownBack")));
            this.btng.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btng.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btng.Location = new System.Drawing.Point(141, 56);
            this.btng.Margin = new System.Windows.Forms.Padding(0);
            this.btng.MouseBack = ((System.Drawing.Image)(resources.GetObject("btng.MouseBack")));
            this.btng.Name = "btng";
            this.btng.NormlBack = ((System.Drawing.Image)(resources.GetObject("btng.NormlBack")));
            this.btng.Radius = 4;
            this.btng.Size = new System.Drawing.Size(25, 24);
            this.btng.TabIndex = 20;
            this.btng.Tag = "2";
            this.btng.Text = "g";
            this.btng.UseMnemonic = false;
            this.btng.UseVisualStyleBackColor = false;
            this.btng.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnf
            // 
            this.btnf.BackColor = System.Drawing.Color.White;
            this.btnf.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnf.BackgroundImage")));
            this.btnf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnf.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnf.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnf.DownBack = ((System.Drawing.Image)(resources.GetObject("btnf.DownBack")));
            this.btnf.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnf.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnf.Location = new System.Drawing.Point(115, 56);
            this.btnf.Margin = new System.Windows.Forms.Padding(0);
            this.btnf.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnf.MouseBack")));
            this.btnf.Name = "btnf";
            this.btnf.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnf.NormlBack")));
            this.btnf.Radius = 4;
            this.btnf.Size = new System.Drawing.Size(25, 24);
            this.btnf.TabIndex = 19;
            this.btnf.Tag = "2";
            this.btnf.Text = "f";
            this.btnf.UseMnemonic = false;
            this.btnf.UseVisualStyleBackColor = false;
            this.btnf.Click += new System.EventHandler(this.btn_Click);
            // 
            // btne
            // 
            this.btne.BackColor = System.Drawing.Color.White;
            this.btne.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btne.BackgroundImage")));
            this.btne.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btne.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btne.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btne.DownBack = ((System.Drawing.Image)(resources.GetObject("btne.DownBack")));
            this.btne.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btne.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btne.Location = new System.Drawing.Point(89, 56);
            this.btne.Margin = new System.Windows.Forms.Padding(0);
            this.btne.MouseBack = ((System.Drawing.Image)(resources.GetObject("btne.MouseBack")));
            this.btne.Name = "btne";
            this.btne.NormlBack = ((System.Drawing.Image)(resources.GetObject("btne.NormlBack")));
            this.btne.Radius = 4;
            this.btne.Size = new System.Drawing.Size(25, 24);
            this.btne.TabIndex = 18;
            this.btne.Tag = "2";
            this.btne.Text = "e";
            this.btne.UseMnemonic = false;
            this.btne.UseVisualStyleBackColor = false;
            this.btne.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnd
            // 
            this.btnd.BackColor = System.Drawing.Color.White;
            this.btnd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnd.BackgroundImage")));
            this.btnd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnd.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnd.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnd.DownBack = ((System.Drawing.Image)(resources.GetObject("btnd.DownBack")));
            this.btnd.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnd.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnd.Location = new System.Drawing.Point(63, 56);
            this.btnd.Margin = new System.Windows.Forms.Padding(0);
            this.btnd.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnd.MouseBack")));
            this.btnd.Name = "btnd";
            this.btnd.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnd.NormlBack")));
            this.btnd.Radius = 4;
            this.btnd.Size = new System.Drawing.Size(25, 24);
            this.btnd.TabIndex = 17;
            this.btnd.Tag = "2";
            this.btnd.Text = "d";
            this.btnd.UseMnemonic = false;
            this.btnd.UseVisualStyleBackColor = false;
            this.btnd.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnc
            // 
            this.btnc.BackColor = System.Drawing.Color.White;
            this.btnc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnc.BackgroundImage")));
            this.btnc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnc.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnc.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnc.DownBack = ((System.Drawing.Image)(resources.GetObject("btnc.DownBack")));
            this.btnc.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnc.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnc.Location = new System.Drawing.Point(37, 56);
            this.btnc.Margin = new System.Windows.Forms.Padding(0);
            this.btnc.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnc.MouseBack")));
            this.btnc.Name = "btnc";
            this.btnc.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnc.NormlBack")));
            this.btnc.Radius = 4;
            this.btnc.Size = new System.Drawing.Size(25, 24);
            this.btnc.TabIndex = 16;
            this.btnc.Tag = "2";
            this.btnc.Text = "c";
            this.btnc.UseMnemonic = false;
            this.btnc.UseVisualStyleBackColor = false;
            this.btnc.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnb
            // 
            this.btnb.BackColor = System.Drawing.Color.White;
            this.btnb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnb.BackgroundImage")));
            this.btnb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnb.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnb.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnb.DownBack = ((System.Drawing.Image)(resources.GetObject("btnb.DownBack")));
            this.btnb.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnb.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnb.Location = new System.Drawing.Point(11, 56);
            this.btnb.Margin = new System.Windows.Forms.Padding(0);
            this.btnb.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnb.MouseBack")));
            this.btnb.Name = "btnb";
            this.btnb.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnb.NormlBack")));
            this.btnb.Radius = 4;
            this.btnb.Size = new System.Drawing.Size(25, 24);
            this.btnb.TabIndex = 15;
            this.btnb.Tag = "2";
            this.btnb.Text = "b";
            this.btnb.UseMnemonic = false;
            this.btnb.UseVisualStyleBackColor = false;
            this.btnb.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.White;
            this.btn6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn6.BackgroundImage")));
            this.btn6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn6.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn6.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn6.DownBack = ((System.Drawing.Image)(resources.GetObject("btn6.DownBack")));
            this.btn6.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn6.Location = new System.Drawing.Point(271, 4);
            this.btn6.Margin = new System.Windows.Forms.Padding(0);
            this.btn6.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn6.MouseBack")));
            this.btn6.Name = "btn6";
            this.btn6.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn6.NormlBack")));
            this.btn6.Radius = 4;
            this.btn6.Size = new System.Drawing.Size(25, 24);
            this.btn6.TabIndex = 14;
            this.btn6.Tag = "1^6";
            this.btn6.Text = "6";
            this.btn6.UseMnemonic = false;
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.White;
            this.btn5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn5.BackgroundImage")));
            this.btn5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn5.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn5.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn5.DownBack = ((System.Drawing.Image)(resources.GetObject("btn5.DownBack")));
            this.btn5.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn5.Location = new System.Drawing.Point(245, 4);
            this.btn5.Margin = new System.Windows.Forms.Padding(0);
            this.btn5.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn5.MouseBack")));
            this.btn5.Name = "btn5";
            this.btn5.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn5.NormlBack")));
            this.btn5.Radius = 4;
            this.btn5.Size = new System.Drawing.Size(25, 24);
            this.btn5.TabIndex = 13;
            this.btn5.Tag = "1%5";
            this.btn5.Text = "5";
            this.btn5.UseMnemonic = false;
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.White;
            this.btn4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn4.BackgroundImage")));
            this.btn4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn4.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn4.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn4.DownBack = ((System.Drawing.Image)(resources.GetObject("btn4.DownBack")));
            this.btn4.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn4.Location = new System.Drawing.Point(219, 4);
            this.btn4.Margin = new System.Windows.Forms.Padding(0);
            this.btn4.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn4.MouseBack")));
            this.btn4.Name = "btn4";
            this.btn4.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn4.NormlBack")));
            this.btn4.Radius = 4;
            this.btn4.Size = new System.Drawing.Size(25, 24);
            this.btn4.TabIndex = 12;
            this.btn4.Tag = "1$4";
            this.btn4.Text = "4";
            this.btn4.UseMnemonic = false;
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.White;
            this.btn3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn3.BackgroundImage")));
            this.btn3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn3.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn3.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn3.DownBack = ((System.Drawing.Image)(resources.GetObject("btn3.DownBack")));
            this.btn3.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn3.Location = new System.Drawing.Point(193, 4);
            this.btn3.Margin = new System.Windows.Forms.Padding(0);
            this.btn3.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn3.MouseBack")));
            this.btn3.Name = "btn3";
            this.btn3.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn3.NormlBack")));
            this.btn3.Radius = 4;
            this.btn3.Size = new System.Drawing.Size(25, 24);
            this.btn3.TabIndex = 11;
            this.btn3.Tag = "1#3";
            this.btn3.Text = "3";
            this.btn3.UseMnemonic = false;
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.White;
            this.btn2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn2.BackgroundImage")));
            this.btn2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn2.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn2.DownBack = ((System.Drawing.Image)(resources.GetObject("btn2.DownBack")));
            this.btn2.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn2.Location = new System.Drawing.Point(167, 4);
            this.btn2.Margin = new System.Windows.Forms.Padding(0);
            this.btn2.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn2.MouseBack")));
            this.btn2.Name = "btn2";
            this.btn2.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn2.NormlBack")));
            this.btn2.Radius = 4;
            this.btn2.Size = new System.Drawing.Size(25, 24);
            this.btn2.TabIndex = 10;
            this.btn2.Tag = "1@2";
            this.btn2.Text = "2";
            this.btn2.UseMnemonic = false;
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.White;
            this.btn1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn1.BackgroundImage")));
            this.btn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn1.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn1.DownBack = ((System.Drawing.Image)(resources.GetObject("btn1.DownBack")));
            this.btn1.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn1.Location = new System.Drawing.Point(141, 4);
            this.btn1.Margin = new System.Windows.Forms.Padding(0);
            this.btn1.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn1.MouseBack")));
            this.btn1.Name = "btn1";
            this.btn1.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn1.NormlBack")));
            this.btn1.Radius = 4;
            this.btn1.Size = new System.Drawing.Size(25, 24);
            this.btn1.TabIndex = 9;
            this.btn1.Tag = "1!1";
            this.btn1.Text = "1";
            this.btn1.UseMnemonic = false;
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnd1
            // 
            this.btnd1.BackColor = System.Drawing.Color.White;
            this.btnd1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnd1.BackgroundImage")));
            this.btnd1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnd1.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnd1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnd1.DownBack = ((System.Drawing.Image)(resources.GetObject("btnd1.DownBack")));
            this.btnd1.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnd1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnd1.Location = new System.Drawing.Point(115, 4);
            this.btnd1.Margin = new System.Windows.Forms.Padding(0);
            this.btnd1.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnd1.MouseBack")));
            this.btnd1.Name = "btnd1";
            this.btnd1.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnd1.NormlBack")));
            this.btnd1.Radius = 4;
            this.btnd1.Size = new System.Drawing.Size(25, 24);
            this.btnd1.TabIndex = 8;
            this.btnd1.Tag = "1~`";
            this.btnd1.Text = "`";
            this.btnd1.UseMnemonic = false;
            this.btnd1.UseVisualStyleBackColor = false;
            this.btnd1.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.White;
            this.btn0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn0.BackgroundImage")));
            this.btn0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn0.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn0.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn0.DownBack = ((System.Drawing.Image)(resources.GetObject("btn0.DownBack")));
            this.btn0.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn0.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn0.Location = new System.Drawing.Point(89, 4);
            this.btn0.Margin = new System.Windows.Forms.Padding(0);
            this.btn0.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn0.MouseBack")));
            this.btn0.Name = "btn0";
            this.btn0.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn0.NormlBack")));
            this.btn0.Radius = 4;
            this.btn0.Size = new System.Drawing.Size(25, 24);
            this.btn0.TabIndex = 7;
            this.btn0.Tag = "1)0";
            this.btn0.Text = "0";
            this.btn0.UseMnemonic = false;
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.White;
            this.btn9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn9.BackgroundImage")));
            this.btn9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn9.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn9.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn9.DownBack = ((System.Drawing.Image)(resources.GetObject("btn9.DownBack")));
            this.btn9.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn9.Location = new System.Drawing.Point(63, 4);
            this.btn9.Margin = new System.Windows.Forms.Padding(0);
            this.btn9.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn9.MouseBack")));
            this.btn9.Name = "btn9";
            this.btn9.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn9.NormlBack")));
            this.btn9.Radius = 4;
            this.btn9.Size = new System.Drawing.Size(25, 24);
            this.btn9.TabIndex = 6;
            this.btn9.Tag = "1(9";
            this.btn9.Text = "9";
            this.btn9.UseMnemonic = false;
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.White;
            this.btn8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn8.BackgroundImage")));
            this.btn8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn8.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn8.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn8.DownBack = ((System.Drawing.Image)(resources.GetObject("btn8.DownBack")));
            this.btn8.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn8.Location = new System.Drawing.Point(37, 4);
            this.btn8.Margin = new System.Windows.Forms.Padding(0);
            this.btn8.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn8.MouseBack")));
            this.btn8.Name = "btn8";
            this.btn8.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn8.NormlBack")));
            this.btn8.Radius = 4;
            this.btn8.Size = new System.Drawing.Size(25, 24);
            this.btn8.TabIndex = 5;
            this.btn8.Tag = "1*8";
            this.btn8.Text = "8";
            this.btn8.UseMnemonic = false;
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.White;
            this.btn7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn7.BackgroundImage")));
            this.btn7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn7.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btn7.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btn7.DownBack = ((System.Drawing.Image)(resources.GetObject("btn7.DownBack")));
            this.btn7.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btn7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn7.Location = new System.Drawing.Point(11, 4);
            this.btn7.Margin = new System.Windows.Forms.Padding(0);
            this.btn7.MouseBack = ((System.Drawing.Image)(resources.GetObject("btn7.MouseBack")));
            this.btn7.Name = "btn7";
            this.btn7.NormlBack = ((System.Drawing.Image)(resources.GetObject("btn7.NormlBack")));
            this.btn7.Radius = 4;
            this.btn7.Size = new System.Drawing.Size(25, 24);
            this.btn7.TabIndex = 4;
            this.btn7.Tag = "1&7";
            this.btn7.Text = "7";
            this.btn7.UseMnemonic = false;
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnShift
            // 
            this.btnShift.BackColor = System.Drawing.Color.White;
            this.btnShift.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnShift.BackgroundImage")));
            this.btnShift.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnShift.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnShift.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnShift.DownBack = ((System.Drawing.Image)(resources.GetObject("btnShift.DownBack")));
            this.btnShift.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnShift.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnShift.Location = new System.Drawing.Point(3, 30);
            this.btnShift.Margin = new System.Windows.Forms.Padding(0);
            this.btnShift.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnShift.MouseBack")));
            this.btnShift.Name = "btnShift";
            this.btnShift.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnShift.NormlBack")));
            this.btnShift.Palace = true;
            this.btnShift.Radius = 4;
            this.btnShift.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.btnShift.Size = new System.Drawing.Size(40, 24);
            this.btnShift.TabIndex = 3;
            this.btnShift.Tag = "3";
            this.btnShift.Text = "Shift";
            this.btnShift.UseMnemonic = false;
            this.btnShift.UseVisualStyleBackColor = false;
            this.btnShift.Click += new System.EventHandler(this.btnShift_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClose.BackgroundImage")));
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnClose.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnClose.DownBack = ((System.Drawing.Image)(resources.GetObject("btnClose.DownBack")));
            this.btnClose.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnClose.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnClose.Location = new System.Drawing.Point(344, 5);
            this.btnClose.Margin = new System.Windows.Forms.Padding(0);
            this.btnClose.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnClose.MouseBack")));
            this.btnClose.Name = "btnClose";
            this.btnClose.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnClose.NormlBack")));
            this.btnClose.Radius = 4;
            this.btnClose.Size = new System.Drawing.Size(11, 11);
            this.btnClose.TabIndex = 2;
            this.btnClose.Tag = "3";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCapsLock
            // 
            this.btnCapsLock.BackColor = System.Drawing.Color.White;
            this.btnCapsLock.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCapsLock.BackgroundImage")));
            this.btnCapsLock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCapsLock.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnCapsLock.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnCapsLock.DownBack = ((System.Drawing.Image)(resources.GetObject("btnCapsLock.DownBack")));
            this.btnCapsLock.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnCapsLock.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnCapsLock.Location = new System.Drawing.Point(293, 30);
            this.btnCapsLock.Margin = new System.Windows.Forms.Padding(0);
            this.btnCapsLock.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnCapsLock.MouseBack")));
            this.btnCapsLock.Name = "btnCapsLock";
            this.btnCapsLock.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnCapsLock.NormlBack")));
            this.btnCapsLock.Radius = 4;
            this.btnCapsLock.Size = new System.Drawing.Size(64, 24);
            this.btnCapsLock.TabIndex = 1;
            this.btnCapsLock.Tag = "3";
            this.btnCapsLock.Text = "Caps Lock";
            this.btnCapsLock.UseMnemonic = false;
            this.btnCapsLock.UseVisualStyleBackColor = false;
            this.btnCapsLock.Click += new System.EventHandler(this.btnCapsLock_Click);
            // 
            // btnDelet
            // 
            this.btnDelet.BackColor = System.Drawing.Color.White;
            this.btnDelet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelet.BackgroundImage")));
            this.btnDelet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDelet.BackRectangle = new System.Drawing.Rectangle(4, 4, 4, 4);
            this.btnDelet.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.btnDelet.DownBack = ((System.Drawing.Image)(resources.GetObject("btnDelet.DownBack")));
            this.btnDelet.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.btnDelet.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnDelet.Location = new System.Drawing.Point(297, 4);
            this.btnDelet.Margin = new System.Windows.Forms.Padding(0);
            this.btnDelet.MouseBack = ((System.Drawing.Image)(resources.GetObject("btnDelet.MouseBack")));
            this.btnDelet.Name = "btnDelet";
            this.btnDelet.NormlBack = ((System.Drawing.Image)(resources.GetObject("btnDelet.NormlBack")));
            this.btnDelet.Radius = 4;
            this.btnDelet.Size = new System.Drawing.Size(45, 24);
            this.btnDelet.TabIndex = 0;
            this.btnDelet.Tag = "3";
            this.btnDelet.Text = "←";
            this.btnDelet.UseMnemonic = false;
            this.btnDelet.UseVisualStyleBackColor = false;
            this.btnDelet.Click += new System.EventHandler(this.btnDelet_Click);
            // 
            // KeyBoardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(173)))), ((int)(((byte)(72)))));
            this.ClientSize = new System.Drawing.Size(360, 110);
            this.ControlBox = false;
            this.Controls.Add(this.btnhx2);
            this.Controls.Add(this.btndh);
            this.Controls.Add(this.btnjh);
            this.Controls.Add(this.btnhx);
            this.Controls.Add(this.btnd4);
            this.Controls.Add(this.btnd3);
            this.Controls.Add(this.btnd2);
            this.Controls.Add(this.btnMh);
            this.Controls.Add(this.btnKh2);
            this.Controls.Add(this.btnKh1);
            this.Controls.Add(this.btny);
            this.Controls.Add(this.btnx);
            this.Controls.Add(this.btnw);
            this.Controls.Add(this.btnv);
            this.Controls.Add(this.btnu);
            this.Controls.Add(this.btnt);
            this.Controls.Add(this.btns);
            this.Controls.Add(this.btnr);
            this.Controls.Add(this.btnq);
            this.Controls.Add(this.btnp);
            this.Controls.Add(this.btno);
            this.Controls.Add(this.btnn);
            this.Controls.Add(this.btnz);
            this.Controls.Add(this.btna);
            this.Controls.Add(this.btnm);
            this.Controls.Add(this.btnl);
            this.Controls.Add(this.btnk);
            this.Controls.Add(this.btnj);
            this.Controls.Add(this.btni);
            this.Controls.Add(this.btnh);
            this.Controls.Add(this.btng);
            this.Controls.Add(this.btnf);
            this.Controls.Add(this.btne);
            this.Controls.Add(this.btnd);
            this.Controls.Add(this.btnc);
            this.Controls.Add(this.btnb);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btnd1);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btnShift);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCapsLock);
            this.Controls.Add(this.btnDelet);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "KeyBoardForm";
            this.Opacity = 0.7D;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "QQ";
            this.TopMost = true;
            this.Deactivate += new System.EventHandler(this.PassKey_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PassKey_FormClosing);
            this.Load += new System.EventHandler(this.PassKey_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private SkinButton btnDelet;
        private SkinButton btnCapsLock;
        private SkinButton btnClose;
        private SkinButton btnShift;
        private SkinButton btn7;
        private System.Windows.Forms.ToolTip toolShow;
        private SkinButton btn8;
        private SkinButton btn0;
        private SkinButton btn9;
        private SkinButton btn3;
        private SkinButton btn2;
        private SkinButton btn1;
        private SkinButton btnd1;
        private SkinButton btn6;
        private SkinButton btn5;
        private SkinButton btn4;
        private SkinButton btnl;
        private SkinButton btnk;
        private SkinButton btnj;
        private SkinButton btni;
        private SkinButton btnh;
        private SkinButton btng;
        private SkinButton btnf;
        private SkinButton btne;
        private SkinButton btnd;
        private SkinButton btnc;
        private SkinButton btnb;
        private SkinButton btna;
        private SkinButton btnm;
        private SkinButton btny;
        private SkinButton btnx;
        private SkinButton btnw;
        private SkinButton btnv;
        private SkinButton btnu;
        private SkinButton btnt;
        private SkinButton btns;
        private SkinButton btnr;
        private SkinButton btnq;
        private SkinButton btnp;
        private SkinButton btno;
        private SkinButton btnn;
        private SkinButton btnz;
        private SkinButton btnhx2;
        private SkinButton btndh;
        private SkinButton btnjh;
        private SkinButton btnhx;
        private SkinButton btnd4;
        private SkinButton btnd3;
        private SkinButton btnd2;
        private SkinButton btnMh;
        private SkinButton btnKh2;
        private SkinButton btnKh1;
    }
}