﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Teleware.ZPG.Client.Module
{
    /// <summary>
    /// 网络连接断开控件
    /// </summary>
    public partial class NetDisconnectControl : UserControl
    {
        public NetDisconnectControl()
        {
            InitializeComponent();
        }
    }
}
