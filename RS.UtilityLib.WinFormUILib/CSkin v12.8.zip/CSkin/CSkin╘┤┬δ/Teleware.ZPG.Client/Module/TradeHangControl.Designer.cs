﻿namespace Teleware.ZPG.Client.Module
{
    partial class TradeHangControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.skinPanel2 = new CCWin.SkinControl.SkinPanel();
            this.skinLabel2 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel1 = new CCWin.SkinControl.SkinLabel();
            this.skinButton1 = new CCWin.SkinControl.SkinButton();
            this.skinTextBox2 = new CCWin.SkinControl.SkinTextBox();
            this.skinTextBox1 = new CCWin.SkinControl.SkinTextBox();
            this.skinRichTextBox1 = new CCWin.SkinControl.SkinRichTextBox();
            this.skinLabel11 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel7 = new CCWin.SkinControl.SkinLabel();
            this.panelDownTime = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox6 = new CCWin.SkinControl.SkinPictureBox();
            this.skinPictureBox5 = new CCWin.SkinControl.SkinPictureBox();
            this.skinPictureBox7 = new CCWin.SkinControl.SkinPictureBox();
            this.skinPictureBox4 = new CCWin.SkinControl.SkinPictureBox();
            this.skinPictureBox3 = new CCWin.SkinControl.SkinPictureBox();
            this.skinPictureBox2 = new CCWin.SkinControl.SkinPictureBox();
            this.panel_info = new CCWin.SkinControl.SkinPanel();
            this.skinLabel10 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel9 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel8 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel6 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel5 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel4 = new CCWin.SkinControl.SkinLabel();
            this.panelMain = new CCWin.SkinControl.SkinPanel();
            this.panelLoading = new CCWin.SkinControl.SkinPanel();
            this.skinPanel3 = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox1 = new CCWin.SkinControl.SkinPictureBox();
            this.skinLabel3 = new CCWin.SkinControl.SkinLabel();
            this.listView1 = new Teleware.ZPG.Client.Controls.ListViewEx();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.skinPanel2.SuspendLayout();
            this.skinTextBox2.SuspendLayout();
            this.skinTextBox1.SuspendLayout();
            this.panelDownTime.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox2)).BeginInit();
            this.panel_info.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.panelLoading.SuspendLayout();
            this.skinPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // skinPanel2
            // 
            this.skinPanel2.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel2.Controls.Add(this.skinLabel2);
            this.skinPanel2.Controls.Add(this.skinLabel1);
            this.skinPanel2.Controls.Add(this.skinButton1);
            this.skinPanel2.Controls.Add(this.skinTextBox2);
            this.skinPanel2.Controls.Add(this.skinTextBox1);
            this.skinPanel2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel2.DownBack = null;
            this.skinPanel2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPanel2.Location = new System.Drawing.Point(332, 228);
            this.skinPanel2.MouseBack = null;
            this.skinPanel2.Name = "skinPanel2";
            this.skinPanel2.NormlBack = null;
            this.skinPanel2.Size = new System.Drawing.Size(340, 258);
            this.skinPanel2.TabIndex = 16;
            // 
            // skinLabel2
            // 
            this.skinLabel2.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel2.AutoSize = true;
            this.skinLabel2.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel2.BorderColor = System.Drawing.Color.White;
            this.skinLabel2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel2.ForeColor = System.Drawing.Color.Black;
            this.skinLabel2.Location = new System.Drawing.Point(23, 110);
            this.skinLabel2.Name = "skinLabel2";
            this.skinLabel2.Size = new System.Drawing.Size(68, 17);
            this.skinLabel2.TabIndex = 17;
            this.skinLabel2.Text = "确认报价：";
            // 
            // skinLabel1
            // 
            this.skinLabel1.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel1.AutoSize = true;
            this.skinLabel1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel1.BorderColor = System.Drawing.Color.White;
            this.skinLabel1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel1.ForeColor = System.Drawing.Color.Black;
            this.skinLabel1.Location = new System.Drawing.Point(23, 57);
            this.skinLabel1.Name = "skinLabel1";
            this.skinLabel1.Size = new System.Drawing.Size(68, 17);
            this.skinLabel1.TabIndex = 16;
            this.skinLabel1.Text = "竞买报价：";
            // 
            // skinButton1
            // 
            this.skinButton1.BackColor = System.Drawing.Color.Transparent;
            this.skinButton1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton1.DownBack = global::Teleware.ZPG.Client.Properties.Resources.baojia_down;
            this.skinButton1.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton1.ForeColor = System.Drawing.Color.White;
            this.skinButton1.Location = new System.Drawing.Point(118, 169);
            this.skinButton1.MouseBack = global::Teleware.ZPG.Client.Properties.Resources.baojia_hover;
            this.skinButton1.Name = "skinButton1";
            this.skinButton1.NormlBack = global::Teleware.ZPG.Client.Properties.Resources.baojia_normal;
            this.skinButton1.Size = new System.Drawing.Size(120, 50);
            this.skinButton1.TabIndex = 15;
            this.skinButton1.Text = "提交报价";
            this.skinButton1.UseVisualStyleBackColor = false;
            // 
            // skinTextBox2
            // 
            this.skinTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.skinTextBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTextBox2.Icon = null;
            this.skinTextBox2.IconIsButton = false;
            this.skinTextBox2.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox2.Location = new System.Drawing.Point(103, 105);
            this.skinTextBox2.Margin = new System.Windows.Forms.Padding(0);
            this.skinTextBox2.MinimumSize = new System.Drawing.Size(28, 28);
            this.skinTextBox2.MouseBack = null;
            this.skinTextBox2.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox2.Name = "skinTextBox2";
            this.skinTextBox2.NormlBack = null;
            this.skinTextBox2.Padding = new System.Windows.Forms.Padding(5);
            this.skinTextBox2.Size = new System.Drawing.Size(185, 28);
            // 
            // skinTextBox2.BaseText
            // 
            this.skinTextBox2.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinTextBox2.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTextBox2.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.skinTextBox2.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.skinTextBox2.SkinTxt.Name = "BaseText";
            this.skinTextBox2.SkinTxt.Size = new System.Drawing.Size(175, 18);
            this.skinTextBox2.SkinTxt.TabIndex = 0;
            this.skinTextBox2.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox2.SkinTxt.WaterText = "";
            this.skinTextBox2.TabIndex = 14;
            // 
            // skinTextBox1
            // 
            this.skinTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.skinTextBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTextBox1.Icon = null;
            this.skinTextBox1.IconIsButton = false;
            this.skinTextBox1.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox1.Location = new System.Drawing.Point(103, 52);
            this.skinTextBox1.Margin = new System.Windows.Forms.Padding(0);
            this.skinTextBox1.MinimumSize = new System.Drawing.Size(28, 28);
            this.skinTextBox1.MouseBack = null;
            this.skinTextBox1.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox1.Name = "skinTextBox1";
            this.skinTextBox1.NormlBack = null;
            this.skinTextBox1.Padding = new System.Windows.Forms.Padding(5);
            this.skinTextBox1.Size = new System.Drawing.Size(185, 28);
            // 
            // skinTextBox1.BaseText
            // 
            this.skinTextBox1.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinTextBox1.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTextBox1.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.skinTextBox1.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.skinTextBox1.SkinTxt.Name = "BaseText";
            this.skinTextBox1.SkinTxt.Size = new System.Drawing.Size(175, 18);
            this.skinTextBox1.SkinTxt.TabIndex = 0;
            this.skinTextBox1.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox1.SkinTxt.WaterText = "";
            this.skinTextBox1.TabIndex = 14;
            // 
            // skinRichTextBox1
            // 
            this.skinRichTextBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinRichTextBox1.Location = new System.Drawing.Point(678, 6);
            this.skinRichTextBox1.Name = "skinRichTextBox1";
            this.skinRichTextBox1.Size = new System.Drawing.Size(214, 480);
            this.skinRichTextBox1.TabIndex = 13;
            this.skinRichTextBox1.Text = "这里显示系统消息...";
            // 
            // skinLabel11
            // 
            this.skinLabel11.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel11.AutoSize = true;
            this.skinLabel11.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel11.BorderColor = System.Drawing.Color.White;
            this.skinLabel11.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel11.ForeColor = System.Drawing.Color.Black;
            this.skinLabel11.Location = new System.Drawing.Point(332, 175);
            this.skinLabel11.Name = "skinLabel11";
            this.skinLabel11.Size = new System.Drawing.Size(107, 19);
            this.skinLabel11.TabIndex = 11;
            this.skinLabel11.Text = "当前阶段：挂牌";
            // 
            // skinLabel7
            // 
            this.skinLabel7.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel7.AutoSize = true;
            this.skinLabel7.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel7.BorderColor = System.Drawing.Color.White;
            this.skinLabel7.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel7.ForeColor = System.Drawing.Color.Black;
            this.skinLabel7.Location = new System.Drawing.Point(332, 121);
            this.skinLabel7.Name = "skinLabel7";
            this.skinLabel7.Size = new System.Drawing.Size(205, 19);
            this.skinLabel7.TabIndex = 12;
            this.skinLabel7.Text = "最高报价：888888888.8 万元";
            // 
            // panelDownTime
            // 
            this.panelDownTime.BackColor = System.Drawing.Color.Transparent;
            this.panelDownTime.Controls.Add(this.skinPictureBox6);
            this.panelDownTime.Controls.Add(this.skinPictureBox5);
            this.panelDownTime.Controls.Add(this.skinPictureBox7);
            this.panelDownTime.Controls.Add(this.skinPictureBox4);
            this.panelDownTime.Controls.Add(this.skinPictureBox3);
            this.panelDownTime.Controls.Add(this.skinPictureBox2);
            this.panelDownTime.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.panelDownTime.DownBack = global::Teleware.ZPG.Client.Properties.Resources.背景;
            this.panelDownTime.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panelDownTime.Location = new System.Drawing.Point(332, 6);
            this.panelDownTime.MouseBack = global::Teleware.ZPG.Client.Properties.Resources.背景;
            this.panelDownTime.Name = "panelDownTime";
            this.panelDownTime.NormlBack = global::Teleware.ZPG.Client.Properties.Resources.背景;
            this.panelDownTime.Size = new System.Drawing.Size(340, 90);
            this.panelDownTime.TabIndex = 9;
            // 
            // skinPictureBox6
            // 
            this.skinPictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPictureBox6.Image = global::Teleware.ZPG.Client.Properties.Resources.大版4;
            this.skinPictureBox6.Location = new System.Drawing.Point(173, 10);
            this.skinPictureBox6.Name = "skinPictureBox6";
            this.skinPictureBox6.Size = new System.Drawing.Size(40, 60);
            this.skinPictureBox6.TabIndex = 6;
            this.skinPictureBox6.TabStop = false;
            // 
            // skinPictureBox5
            // 
            this.skinPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPictureBox5.Image = global::Teleware.ZPG.Client.Properties.Resources.大版5;
            this.skinPictureBox5.Location = new System.Drawing.Point(220, 10);
            this.skinPictureBox5.Name = "skinPictureBox5";
            this.skinPictureBox5.Size = new System.Drawing.Size(40, 60);
            this.skinPictureBox5.TabIndex = 6;
            this.skinPictureBox5.TabStop = false;
            // 
            // skinPictureBox7
            // 
            this.skinPictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPictureBox7.Image = global::Teleware.ZPG.Client.Properties.Resources.大版秒;
            this.skinPictureBox7.Location = new System.Drawing.Point(267, 35);
            this.skinPictureBox7.Name = "skinPictureBox7";
            this.skinPictureBox7.Size = new System.Drawing.Size(35, 35);
            this.skinPictureBox7.TabIndex = 6;
            this.skinPictureBox7.TabStop = false;
            // 
            // skinPictureBox4
            // 
            this.skinPictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPictureBox4.Image = global::Teleware.ZPG.Client.Properties.Resources.大版分;
            this.skinPictureBox4.Location = new System.Drawing.Point(131, 35);
            this.skinPictureBox4.Name = "skinPictureBox4";
            this.skinPictureBox4.Size = new System.Drawing.Size(35, 35);
            this.skinPictureBox4.TabIndex = 6;
            this.skinPictureBox4.TabStop = false;
            // 
            // skinPictureBox3
            // 
            this.skinPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPictureBox3.Image = global::Teleware.ZPG.Client.Properties.Resources.大版2;
            this.skinPictureBox3.Location = new System.Drawing.Point(84, 10);
            this.skinPictureBox3.Name = "skinPictureBox3";
            this.skinPictureBox3.Size = new System.Drawing.Size(40, 60);
            this.skinPictureBox3.TabIndex = 6;
            this.skinPictureBox3.TabStop = false;
            // 
            // skinPictureBox2
            // 
            this.skinPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPictureBox2.Image = global::Teleware.ZPG.Client.Properties.Resources.大版0;
            this.skinPictureBox2.Location = new System.Drawing.Point(37, 10);
            this.skinPictureBox2.Name = "skinPictureBox2";
            this.skinPictureBox2.Size = new System.Drawing.Size(40, 60);
            this.skinPictureBox2.TabIndex = 6;
            this.skinPictureBox2.TabStop = false;
            // 
            // panel_info
            // 
            this.panel_info.BackColor = System.Drawing.Color.Transparent;
            this.panel_info.Controls.Add(this.skinLabel10);
            this.panel_info.Controls.Add(this.skinLabel9);
            this.panel_info.Controls.Add(this.skinLabel8);
            this.panel_info.Controls.Add(this.skinLabel6);
            this.panel_info.Controls.Add(this.skinLabel5);
            this.panel_info.Controls.Add(this.skinLabel4);
            this.panel_info.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.panel_info.DownBack = null;
            this.panel_info.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panel_info.Location = new System.Drawing.Point(6, 6);
            this.panel_info.MouseBack = null;
            this.panel_info.Name = "panel_info";
            this.panel_info.NormlBack = null;
            this.panel_info.Palace = true;
            this.panel_info.Size = new System.Drawing.Size(320, 180);
            this.panel_info.TabIndex = 7;
            // 
            // skinLabel10
            // 
            this.skinLabel10.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel10.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel10.BorderColor = System.Drawing.Color.White;
            this.skinLabel10.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.skinLabel10.Location = new System.Drawing.Point(3, 150);
            this.skinLabel10.Name = "skinLabel10";
            this.skinLabel10.Size = new System.Drawing.Size(300, 20);
            this.skinLabel10.TabIndex = 0;
            this.skinLabel10.Text = "拍卖阶段加价最低幅度:1000 万元";
            // 
            // skinLabel9
            // 
            this.skinLabel9.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel9.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel9.BorderColor = System.Drawing.Color.White;
            this.skinLabel9.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.skinLabel9.Location = new System.Drawing.Point(3, 122);
            this.skinLabel9.Name = "skinLabel9";
            this.skinLabel9.Size = new System.Drawing.Size(300, 20);
            this.skinLabel9.TabIndex = 0;
            this.skinLabel9.Text = "挂牌阶段加价最低幅度:1000 万元";
            // 
            // skinLabel8
            // 
            this.skinLabel8.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel8.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel8.BorderColor = System.Drawing.Color.White;
            this.skinLabel8.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.skinLabel8.Location = new System.Drawing.Point(3, 94);
            this.skinLabel8.Name = "skinLabel8";
            this.skinLabel8.Size = new System.Drawing.Size(300, 20);
            this.skinLabel8.TabIndex = 0;
            this.skinLabel8.Text = "起始价:1000 万元";
            // 
            // skinLabel6
            // 
            this.skinLabel6.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel6.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel6.BorderColor = System.Drawing.Color.White;
            this.skinLabel6.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.skinLabel6.Location = new System.Drawing.Point(3, 66);
            this.skinLabel6.Name = "skinLabel6";
            this.skinLabel6.Size = new System.Drawing.Size(300, 20);
            this.skinLabel6.TabIndex = 0;
            this.skinLabel6.Text = "面积:1000000 平方米";
            // 
            // skinLabel5
            // 
            this.skinLabel5.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel5.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel5.BorderColor = System.Drawing.Color.White;
            this.skinLabel5.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.skinLabel5.Location = new System.Drawing.Point(3, 38);
            this.skinLabel5.Name = "skinLabel5";
            this.skinLabel5.Size = new System.Drawing.Size(300, 20);
            this.skinLabel5.TabIndex = 0;
            this.skinLabel5.Text = "项目名称:项目名称项目名称项目名称";
            // 
            // skinLabel4
            // 
            this.skinLabel4.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel4.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel4.BorderColor = System.Drawing.Color.White;
            this.skinLabel4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.skinLabel4.Location = new System.Drawing.Point(3, 10);
            this.skinLabel4.Name = "skinLabel4";
            this.skinLabel4.Size = new System.Drawing.Size(300, 20);
            this.skinLabel4.TabIndex = 0;
            this.skinLabel4.Text = "宗地号:福州市0001宗地";
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.Transparent;
            this.panelMain.Controls.Add(this.panel_info);
            this.panelMain.Controls.Add(this.panelDownTime);
            this.panelMain.Controls.Add(this.listView1);
            this.panelMain.Controls.Add(this.skinLabel7);
            this.panelMain.Controls.Add(this.skinLabel11);
            this.panelMain.Controls.Add(this.skinRichTextBox1);
            this.panelMain.Controls.Add(this.skinPanel2);
            this.panelMain.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.DownBack = null;
            this.panelMain.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.MouseBack = null;
            this.panelMain.Name = "panelMain";
            this.panelMain.NormlBack = null;
            this.panelMain.Size = new System.Drawing.Size(898, 494);
            this.panelMain.TabIndex = 17;
            this.panelMain.Visible = false;
            // 
            // panelLoading
            // 
            this.panelLoading.BackColor = System.Drawing.Color.Transparent;
            this.panelLoading.Controls.Add(this.skinPanel3);
            this.panelLoading.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.panelLoading.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLoading.DownBack = null;
            this.panelLoading.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panelLoading.Location = new System.Drawing.Point(0, 0);
            this.panelLoading.MouseBack = null;
            this.panelLoading.Name = "panelLoading";
            this.panelLoading.NormlBack = null;
            this.panelLoading.Size = new System.Drawing.Size(898, 494);
            this.panelLoading.TabIndex = 0;
            // 
            // skinPanel3
            // 
            this.skinPanel3.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel3.Controls.Add(this.skinPictureBox1);
            this.skinPanel3.Controls.Add(this.skinLabel3);
            this.skinPanel3.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel3.DownBack = null;
            this.skinPanel3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPanel3.Location = new System.Drawing.Point(334, 200);
            this.skinPanel3.MouseBack = null;
            this.skinPanel3.Name = "skinPanel3";
            this.skinPanel3.NormlBack = null;
            this.skinPanel3.Size = new System.Drawing.Size(230, 40);
            this.skinPanel3.TabIndex = 8;
            // 
            // skinPictureBox1
            // 
            this.skinPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinPictureBox1.Image = global::Teleware.ZPG.Client.Properties.Resources.loading;
            this.skinPictureBox1.Location = new System.Drawing.Point(2, 4);
            this.skinPictureBox1.Name = "skinPictureBox1";
            this.skinPictureBox1.Size = new System.Drawing.Size(32, 32);
            this.skinPictureBox1.TabIndex = 7;
            this.skinPictureBox1.TabStop = false;
            // 
            // skinLabel3
            // 
            this.skinLabel3.ArtTextStyle = CCWin.SkinControl.ArtTextStyle.None;
            this.skinLabel3.AutoSize = true;
            this.skinLabel3.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel3.BorderColor = System.Drawing.Color.White;
            this.skinLabel3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.skinLabel3.ForeColor = System.Drawing.Color.Black;
            this.skinLabel3.Location = new System.Drawing.Point(36, 8);
            this.skinLabel3.Name = "skinLabel3";
            this.skinLabel3.Size = new System.Drawing.Size(182, 21);
            this.skinLabel3.TabIndex = 3;
            this.skinLabel3.Text = "正在加载数据，请稍后...";
            this.skinLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // listView1
            // 
            this.listView1.AllowChangeHeaderWidth = false;
            this.listView1.AllowColumnReorder = true;
            this.listView1.BackColor = System.Drawing.SystemColors.Window;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listView1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(6, 192);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(320, 294);
            this.listView1.TabIndex = 10;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = " 轮次";
            this.columnHeader2.Width = 45;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "竞买号";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "报价（万元）";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 90;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "时间";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 100;
            // 
            // TradeHangControl
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panelLoading);
            this.Controls.Add(this.panelMain);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "TradeHangControl";
            this.Size = new System.Drawing.Size(898, 494);
            this.Load += new System.EventHandler(this.TradeHangControl_Load);
            this.skinPanel2.ResumeLayout(false);
            this.skinPanel2.PerformLayout();
            this.skinTextBox2.ResumeLayout(false);
            this.skinTextBox2.PerformLayout();
            this.skinTextBox1.ResumeLayout(false);
            this.skinTextBox1.PerformLayout();
            this.panelDownTime.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox2)).EndInit();
            this.panel_info.ResumeLayout(false);
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.panelLoading.ResumeLayout(false);
            this.skinPanel3.ResumeLayout(false);
            this.skinPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CCWin.SkinControl.SkinLabel skinLabel11;
        private CCWin.SkinControl.SkinLabel skinLabel7;
        private Teleware.ZPG.Client.Controls.ListViewEx listView1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private CCWin.SkinControl.SkinPanel panelDownTime;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox6;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox5;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox7;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox4;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox3;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox2;
        private CCWin.SkinControl.SkinPanel panel_info;
        private CCWin.SkinControl.SkinLabel skinLabel10;
        private CCWin.SkinControl.SkinLabel skinLabel9;
        private CCWin.SkinControl.SkinLabel skinLabel8;
        private CCWin.SkinControl.SkinLabel skinLabel6;
        private CCWin.SkinControl.SkinLabel skinLabel5;
        private CCWin.SkinControl.SkinLabel skinLabel4;
        private CCWin.SkinControl.SkinRichTextBox skinRichTextBox1;
        private CCWin.SkinControl.SkinTextBox skinTextBox1;
        private CCWin.SkinControl.SkinTextBox skinTextBox2;
        private CCWin.SkinControl.SkinButton skinButton1;
        private CCWin.SkinControl.SkinPanel skinPanel2;
        private CCWin.SkinControl.SkinLabel skinLabel2;
        private CCWin.SkinControl.SkinLabel skinLabel1;
        private CCWin.SkinControl.SkinPanel panelMain;
        private CCWin.SkinControl.SkinPanel panelLoading;
        private CCWin.SkinControl.SkinPanel skinPanel3;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox1;
        private CCWin.SkinControl.SkinLabel skinLabel3;
    }
}
