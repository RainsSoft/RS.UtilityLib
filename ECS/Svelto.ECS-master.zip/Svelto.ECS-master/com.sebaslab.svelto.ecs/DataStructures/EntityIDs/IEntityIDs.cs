namespace Svelto.ECS.Internal
{
    public interface IEntityIDs { }
}