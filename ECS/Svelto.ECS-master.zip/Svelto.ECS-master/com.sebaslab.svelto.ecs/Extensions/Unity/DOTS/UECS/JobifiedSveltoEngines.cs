#if UNITY_ECS
namespace Svelto.ECS.SveltoOnDOTS
{
    public enum JobifiedSveltoEngines
    {
        SveltoOnDOTS
    }
}
#endif