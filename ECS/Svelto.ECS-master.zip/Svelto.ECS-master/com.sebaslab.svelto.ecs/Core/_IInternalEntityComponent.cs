namespace Svelto.ECS
{
    namespace Internal
    {
        ///<summary>This interfaces shouldn't be used outside the svelto assembly, use interfaces that inherit from this</summary>
        public interface _IInternalEntityComponent
        {
        }    
    }
}