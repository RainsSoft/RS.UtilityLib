namespace Svelto.ECS
{
    public interface IDynamicEntityDescriptor: IEntityDescriptor
    {
    }
}