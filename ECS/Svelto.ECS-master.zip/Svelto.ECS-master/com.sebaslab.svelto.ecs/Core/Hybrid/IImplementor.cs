namespace Svelto.ECS.Hybrid
{
    public interface IImplementor
    {
    }
}