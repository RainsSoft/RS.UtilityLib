using System;

namespace Svelto.ECS
{
    public class AllowMultipleAttribute : Attribute
    {
    }
}