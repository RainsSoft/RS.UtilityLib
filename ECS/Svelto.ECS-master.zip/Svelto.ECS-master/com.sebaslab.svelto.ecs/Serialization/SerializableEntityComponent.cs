namespace Svelto.ECS.Serialization
{
    struct SerializableEntityComponent : IEntityComponent
    {
        public uint descriptorHash;
    }
}