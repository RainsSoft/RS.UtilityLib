using System;

namespace Svelto.ECS.Serialization
{
    public class DoNotSerializeAttribute : Attribute
    {
    }
}