﻿using Entitas;

public interface AnotherComponentInterface : IComponent {
}
