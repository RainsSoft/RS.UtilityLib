public class NestedClass {

    public class InnerClass {
    }
}
