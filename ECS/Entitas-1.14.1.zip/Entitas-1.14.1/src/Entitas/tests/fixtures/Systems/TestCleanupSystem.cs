﻿using Entitas;

public class TestCleanupSystem : ICleanupSystem {

    public void Cleanup() {
    }
}
