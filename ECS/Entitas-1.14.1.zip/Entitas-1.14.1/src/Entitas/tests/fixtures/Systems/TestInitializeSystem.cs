﻿using Entitas;

public class TestInitializeSystem : IInitializeSystem {

    public void Initialize() {
    }
}
