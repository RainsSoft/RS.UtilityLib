﻿using Entitas;

public class TestTearDownSystem : ITearDownSystem {

    public void TearDown() {
    }
}
