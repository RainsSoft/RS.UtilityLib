﻿using Entitas;

public class TestExecuteSystem : IExecuteSystem {

    public void Execute() {
    }
}
