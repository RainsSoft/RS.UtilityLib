public enum SomeEnum {
    Test1,
    Test2,
    Test3
}

public class NestedTest {

    public enum NestedSomeEnum {
        NestedTest1,
        NestedTest2,
        NestedTest3
    }
}
