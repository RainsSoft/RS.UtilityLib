pool.CreateSystem<MySystem1>( );
pool.CreateSystem<MySystem2>();
