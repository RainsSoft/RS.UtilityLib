using Entitas;

public class MoveSystem : ISystem {
}
