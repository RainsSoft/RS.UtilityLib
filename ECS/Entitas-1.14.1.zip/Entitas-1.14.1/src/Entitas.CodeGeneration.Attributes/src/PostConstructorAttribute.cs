﻿using System;

namespace Entitas.CodeGeneration.Attributes
{
    [AttributeUsage(AttributeTargets.Method)]
    public class PostConstructorAttribute : Attribute { }
}
