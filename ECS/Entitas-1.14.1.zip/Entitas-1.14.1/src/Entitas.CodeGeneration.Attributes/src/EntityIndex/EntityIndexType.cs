namespace Entitas.CodeGeneration.Attributes
{
    public enum EntityIndexType
    {
        EntityIndex,
        PrimaryEntityIndex
    }
}
