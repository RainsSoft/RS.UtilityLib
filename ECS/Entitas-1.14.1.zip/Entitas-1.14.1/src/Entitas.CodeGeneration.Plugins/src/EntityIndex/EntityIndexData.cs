﻿using Jenny;

namespace Entitas.CodeGeneration.Plugins
{
    public class EntityIndexData : CodeGeneratorData { }
}
