﻿using Jenny;

namespace Entitas.CodeGeneration.Plugins
{
    public class ContextData : CodeGeneratorData { }
}
