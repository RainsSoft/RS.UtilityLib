﻿using Entitas;

[KnownContext]
public class KnownContextComponent : IComponent {
}
