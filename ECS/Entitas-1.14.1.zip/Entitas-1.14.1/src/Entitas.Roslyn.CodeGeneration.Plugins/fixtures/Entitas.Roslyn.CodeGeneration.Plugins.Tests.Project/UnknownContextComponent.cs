﻿using Entitas;

[UnknownContext]
public class UnknownContextComponent : IComponent {
}
