﻿using Entitas;
using UnityEngine;

[Game]
public sealed class VelocityComponent : IComponent {

    public Vector3 value;
}
