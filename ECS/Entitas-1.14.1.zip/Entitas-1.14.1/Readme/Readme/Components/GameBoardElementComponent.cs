﻿using Entitas;

[Game]
public sealed class GameBoardElementComponent : IComponent {
}
