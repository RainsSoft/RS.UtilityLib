﻿using Entitas;

[Game]
public sealed class InteractiveComponent : IComponent {
}
