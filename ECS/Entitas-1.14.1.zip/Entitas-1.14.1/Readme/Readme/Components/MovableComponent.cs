﻿using Entitas;

[Game]
public sealed class MovableComponent : IComponent {
}
