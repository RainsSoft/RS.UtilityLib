﻿using Entitas;
using Entitas.CodeGeneration.Attributes;

namespace My.Namespace
{
    [Context("Test")]
    public sealed class MyNamespaceFlagComponent : IComponent { }
}
