﻿using Entitas.CodeGeneration.Attributes;

public abstract class AbstractEntityIndexComponent
{
    [EntityIndex]
    public string value;
}
