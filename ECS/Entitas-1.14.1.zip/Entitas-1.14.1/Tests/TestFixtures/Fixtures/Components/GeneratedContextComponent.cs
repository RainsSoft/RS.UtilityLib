﻿using Entitas;

[Game]
public class GeneratedContextComponent : IComponent { }
