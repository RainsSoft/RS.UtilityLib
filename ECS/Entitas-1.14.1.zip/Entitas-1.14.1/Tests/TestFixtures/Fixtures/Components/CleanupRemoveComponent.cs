﻿using Entitas;
using Entitas.CodeGeneration.Attributes;

[Cleanup(CleanupMode.RemoveComponent)]
public sealed class CleanupRemoveComponent : IComponent { }
