﻿using Entitas.CodeGeneration.Attributes;

[Context("Test"), ComponentName("NewCustomNameComponent1", "NewCustomNameComponent2")]
public sealed class CustomName { }
