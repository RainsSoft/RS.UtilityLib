﻿using Entitas;
using Entitas.CodeGeneration.Attributes;

[Context("Test")]
public sealed class FlagComponent : IComponent { }
