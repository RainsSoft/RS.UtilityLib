﻿using Entitas;
using Entitas.CodeGeneration.Attributes;

[Context("Test"), Unique]
public sealed class UniqueFlagComponent : IComponent { }
