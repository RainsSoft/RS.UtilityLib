﻿using Entitas;

public class NoContextComponent : IComponent { }
