﻿using Entitas.CodeGeneration.Attributes;
using Entitas;

[Context("Test")]
public abstract class AbstractComponent : IComponent { }
