﻿using Entitas;

public sealed class Array3dComponent : IComponent
{
    public int[,,] value;
}
