﻿using Entitas.CodeGeneration.Attributes;

[Test]
public class ClassWithEntitIndexAttribute
{
    [EntityIndex]
    public string value;
}
