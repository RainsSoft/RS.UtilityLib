﻿using Entitas.CodeGeneration.Attributes;

namespace My.Namespace
{
    [Context("Test")]
    public struct StructToGenerate
    {
        public string value;
    }
}
