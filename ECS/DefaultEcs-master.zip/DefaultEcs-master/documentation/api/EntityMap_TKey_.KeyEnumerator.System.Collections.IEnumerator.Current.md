#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[EntityMap&lt;TKey&gt;](EntityMap_TKey_.md 'DefaultEcs.EntityMap<TKey>').[KeyEnumerator](EntityMap_TKey_.KeyEnumerator.md 'DefaultEcs.EntityMap<TKey>.KeyEnumerator')

## EntityMap<TKey>.KeyEnumerator.System.Collections.IEnumerator.Current Property

Gets the [TKey](EntityMap_TKey_.KeyEnumerator.md#DefaultEcs.EntityMap_TKey_.KeyEnumerator.TKey 'DefaultEcs.EntityMap<TKey>.KeyEnumerator.TKey') at the current position of the enumerator.

```csharp
object System.Collections.IEnumerator.Current { get; }
```

Implements [Current](https://docs.microsoft.com/en-us/dotnet/api/System.Collections.IEnumerator.Current 'System.Collections.IEnumerator.Current')