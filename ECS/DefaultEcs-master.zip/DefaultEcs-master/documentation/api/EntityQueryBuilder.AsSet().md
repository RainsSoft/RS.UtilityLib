#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[EntityQueryBuilder](EntityQueryBuilder.md 'DefaultEcs.EntityQueryBuilder')

## EntityQueryBuilder.AsSet() Method

Returns an [EntitySet](EntitySet.md 'DefaultEcs.EntitySet') with the specified rules.

```csharp
public DefaultEcs.EntitySet AsSet();
```

#### Returns
[EntitySet](EntitySet.md 'DefaultEcs.EntitySet')  
The [EntitySet](EntitySet.md 'DefaultEcs.EntitySet').