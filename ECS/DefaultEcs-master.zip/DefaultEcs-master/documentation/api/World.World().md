#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[World](World.md 'DefaultEcs.World')

## World() Constructor

Initializes a new instance of the [World](World.md 'DefaultEcs.World') class.

```csharp
public World();
```