#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs.System](DefaultEcs.md#DefaultEcs.System 'DefaultEcs.System').[ComponentAttribute](ComponentAttribute.md 'DefaultEcs.System.ComponentAttribute')

## ComponentAttribute.FilterType Property

Whether the component type should be included or excluded.

```csharp
public DefaultEcs.System.ComponentFilterType FilterType { get; }
```

#### Property Value
[ComponentFilterType](ComponentFilterType.md 'DefaultEcs.System.ComponentFilterType')