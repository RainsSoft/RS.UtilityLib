#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[ComponentCloner](ComponentCloner.md 'DefaultEcs.ComponentCloner')

## ComponentCloner() Constructor

Initialize a new instance of the [ComponentCloner](ComponentCloner.md 'DefaultEcs.ComponentCloner') type.

```csharp
public ComponentCloner();
```