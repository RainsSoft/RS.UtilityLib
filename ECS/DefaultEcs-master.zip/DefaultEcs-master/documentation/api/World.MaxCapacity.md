#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[World](World.md 'DefaultEcs.World')

## World.MaxCapacity Property

Gets the maximum number of [Entity](Entity.md 'DefaultEcs.Entity') this [World](World.md 'DefaultEcs.World') can handle.

```csharp
public int MaxCapacity { get; }
```

#### Property Value
[System.Int32](https://docs.microsoft.com/en-us/dotnet/api/System.Int32 'System.Int32')