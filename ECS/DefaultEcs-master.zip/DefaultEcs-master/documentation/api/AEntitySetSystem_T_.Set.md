#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs.System](DefaultEcs.md#DefaultEcs.System 'DefaultEcs.System').[AEntitySetSystem&lt;T&gt;](AEntitySetSystem_T_.md 'DefaultEcs.System.AEntitySetSystem<T>')

## AEntitySetSystem<T>.Set Property

Gets the [EntitySet](EntitySet.md 'DefaultEcs.EntitySet') instance on which this system operates.

```csharp
public DefaultEcs.EntitySet Set { get; }
```

#### Property Value
[EntitySet](EntitySet.md 'DefaultEcs.EntitySet')