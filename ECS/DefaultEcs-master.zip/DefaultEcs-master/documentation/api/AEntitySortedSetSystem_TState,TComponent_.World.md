#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs.System](DefaultEcs.md#DefaultEcs.System 'DefaultEcs.System').[AEntitySortedSetSystem&lt;TState,TComponent&gt;](AEntitySortedSetSystem_TState,TComponent_.md 'DefaultEcs.System.AEntitySortedSetSystem<TState,TComponent>')

## AEntitySortedSetSystem<TState,TComponent>.World Property

Gets the [World](World.md 'DefaultEcs.World') instance on which this system operates.

```csharp
public DefaultEcs.World World { get; }
```

#### Property Value
[World](World.md 'DefaultEcs.World')