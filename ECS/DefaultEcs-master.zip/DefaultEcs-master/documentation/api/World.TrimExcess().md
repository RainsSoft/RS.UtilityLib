#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[World](World.md 'DefaultEcs.World')

## World.TrimExcess() Method

Resizes all inner storage to exactly the number of [Entity](Entity.md 'DefaultEcs.Entity') and components this [World](World.md 'DefaultEcs.World') contains.  
This method is not thread safe.

```csharp
public void TrimExcess();
```