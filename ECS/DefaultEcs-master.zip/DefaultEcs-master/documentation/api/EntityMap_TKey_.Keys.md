#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[EntityMap&lt;TKey&gt;](EntityMap_TKey_.md 'DefaultEcs.EntityMap<TKey>')

## EntityMap<TKey>.Keys Property

Gets the keys contained in the [EntityMap&lt;TKey&gt;](EntityMap_TKey_.md 'DefaultEcs.EntityMap<TKey>').

```csharp
public DefaultEcs.EntityMap<TKey>.KeyEnumerable Keys { get; }
```

#### Property Value
[DefaultEcs.EntityMap.KeyEnumerable&lt;](EntityMap_TKey_.KeyEnumerable.md 'DefaultEcs.EntityMap<TKey>.KeyEnumerable')[TKey](EntityMap_TKey_.md#DefaultEcs.EntityMap_TKey_.TKey 'DefaultEcs.EntityMap<TKey>.TKey')[&gt;](EntityMap_TKey_.KeyEnumerable.md 'DefaultEcs.EntityMap<TKey>.KeyEnumerable')