#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[World](World.md 'DefaultEcs.World').[Enumerator](World.Enumerator.md 'DefaultEcs.World.Enumerator')

## World.Enumerator.Dispose() Method

Releases all resources used by the [Enumerator](World.Enumerator.md 'DefaultEcs.World.Enumerator').

```csharp
public void Dispose();
```

Implements [Dispose()](https://docs.microsoft.com/en-us/dotnet/api/System.IDisposable.Dispose 'System.IDisposable.Dispose')