#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs.Resource](DefaultEcs.md#DefaultEcs.Resource 'DefaultEcs.Resource').[ManagedResource&lt;TInfo,TResource&gt;](ManagedResource_TInfo,TResource_.md 'DefaultEcs.Resource.ManagedResource<TInfo,TResource>')

## ManagedResource<TInfo,TResource>.Info Field

Gets the info about the resource to load.

```csharp
public readonly TInfo Info;
```

#### Field Value
[TInfo](ManagedResource_TInfo,TResource_.md#DefaultEcs.Resource.ManagedResource_TInfo,TResource_.TInfo 'DefaultEcs.Resource.ManagedResource<TInfo,TResource>.TInfo')