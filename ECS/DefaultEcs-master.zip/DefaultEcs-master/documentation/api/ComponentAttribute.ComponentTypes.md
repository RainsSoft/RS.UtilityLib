#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs.System](DefaultEcs.md#DefaultEcs.System 'DefaultEcs.System').[ComponentAttribute](ComponentAttribute.md 'DefaultEcs.System.ComponentAttribute')

## ComponentAttribute.ComponentTypes Property

The types of the component.

```csharp
public System.Type[] ComponentTypes { get; }
```

#### Property Value
[System.Type](https://docs.microsoft.com/en-us/dotnet/api/System.Type 'System.Type')[[]](https://docs.microsoft.com/en-us/dotnet/api/System.Array 'System.Array')