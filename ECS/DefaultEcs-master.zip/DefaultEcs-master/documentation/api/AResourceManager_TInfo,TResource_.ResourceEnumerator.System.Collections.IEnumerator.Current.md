#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs.Resource](DefaultEcs.md#DefaultEcs.Resource 'DefaultEcs.Resource').[AResourceManager&lt;TInfo,TResource&gt;](AResourceManager_TInfo,TResource_.md 'DefaultEcs.Resource.AResourceManager<TInfo,TResource>').[ResourceEnumerator](AResourceManager_TInfo,TResource_.ResourceEnumerator.md 'DefaultEcs.Resource.AResourceManager<TInfo,TResource>.ResourceEnumerator')

## AResourceManager<TInfo,TResource>.ResourceEnumerator.System.Collections.IEnumerator.Current Property

Gets the resource at the current position of the enumerator.

```csharp
object System.Collections.IEnumerator.Current { get; }
```

Implements [Current](https://docs.microsoft.com/en-us/dotnet/api/System.Collections.IEnumerator.Current 'System.Collections.IEnumerator.Current')