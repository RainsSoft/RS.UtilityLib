#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[Entity](Entity.md 'DefaultEcs.Entity')

## Entity.IsEnabled() Method

Gets whether the current [Entity](Entity.md 'DefaultEcs.Entity') is enabled or not.

```csharp
public bool IsEnabled();
```

#### Returns
[System.Boolean](https://docs.microsoft.com/en-us/dotnet/api/System.Boolean 'System.Boolean')  
true if the [Entity](Entity.md 'DefaultEcs.Entity') is enabled; otherwise, false.