#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs.System](DefaultEcs.md#DefaultEcs.System 'DefaultEcs.System').[AEntityMultiMapSystem&lt;TState,TKey&gt;](AEntityMultiMapSystem_TState,TKey_.md 'DefaultEcs.System.AEntityMultiMapSystem<TState,TKey>')

## AEntityMultiMapSystem<TState,TKey>.World Property

Gets the [World](World.md 'DefaultEcs.World') instance on which this system operates.

```csharp
public DefaultEcs.World World { get; }
```

#### Property Value
[World](World.md 'DefaultEcs.World')