#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[EntitySet](EntitySet.md 'DefaultEcs.EntitySet')

## EntitySet.Count Property

Gets the number of [Entity](Entity.md 'DefaultEcs.Entity') in the current [EntitySet](EntitySet.md 'DefaultEcs.EntitySet').

```csharp
public int Count { get; set; }
```

#### Property Value
[System.Int32](https://docs.microsoft.com/en-us/dotnet/api/System.Int32 'System.Int32')