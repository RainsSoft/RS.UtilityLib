#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs.Serialization](DefaultEcs.md#DefaultEcs.Serialization 'DefaultEcs.Serialization').[TextSerializationContext](TextSerializationContext.md 'DefaultEcs.Serialization.TextSerializationContext')

## TextSerializationContext() Constructor

Initializes a new instance of the [TextSerializationContext](TextSerializationContext.md 'DefaultEcs.Serialization.TextSerializationContext') class.

```csharp
public TextSerializationContext();
```