#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[EntityMultiMap&lt;TKey&gt;](EntityMultiMap_TKey_.md 'DefaultEcs.EntityMultiMap<TKey>')

## EntityMultiMap<TKey>.Keys Property

Gets the keys contained in the [EntityMultiMap&lt;TKey&gt;](EntityMultiMap_TKey_.md 'DefaultEcs.EntityMultiMap<TKey>').

```csharp
public DefaultEcs.EntityMultiMap<TKey>.KeyEnumerable Keys { get; }
```

#### Property Value
[DefaultEcs.EntityMultiMap.KeyEnumerable&lt;](EntityMultiMap_TKey_.KeyEnumerable.md 'DefaultEcs.EntityMultiMap<TKey>.KeyEnumerable')[TKey](EntityMultiMap_TKey_.md#DefaultEcs.EntityMultiMap_TKey_.TKey 'DefaultEcs.EntityMultiMap<TKey>.TKey')[&gt;](EntityMultiMap_TKey_.KeyEnumerable.md 'DefaultEcs.EntityMultiMap<TKey>.KeyEnumerable')