#### [DefaultEcs](DefaultEcs.md 'DefaultEcs')
### [DefaultEcs](DefaultEcs.md#DefaultEcs 'DefaultEcs').[Entity](Entity.md 'DefaultEcs.Entity')

## Entity.World Property

Gets the [World](World.md 'DefaultEcs.World') instance from which current [Entity](Entity.md 'DefaultEcs.Entity') originate.

```csharp
public DefaultEcs.World World { get; }
```

#### Property Value
[World](World.md 'DefaultEcs.World')