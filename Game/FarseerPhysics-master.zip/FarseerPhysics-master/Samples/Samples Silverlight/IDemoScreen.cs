﻿namespace FarseerPhysics
{
    public interface IDemoScreen
    {
        string GetTitle();
        string GetDetails();
    }
}
