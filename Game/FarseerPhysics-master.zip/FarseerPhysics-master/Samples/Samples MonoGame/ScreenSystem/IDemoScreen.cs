﻿namespace FarseerPhysics.Samples.ScreenSystem
{
    public interface IDemoScreen
    {
        string GetTitle();
        string GetDetails();
    }
}