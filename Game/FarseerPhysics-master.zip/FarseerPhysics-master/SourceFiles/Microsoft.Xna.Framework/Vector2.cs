using System;
using System.Text;

namespace Microsoft.Xna.Framework
{
	public struct Vector2 : IEquatable<Vector2>
	{
		private static Vector2 zeroVector = new Vector2(0f, 0f);

		private static Vector2 unitVector = new Vector2(1f, 1f);

		private static Vector2 unitXVector = new Vector2(1f, 0f);

		private static Vector2 unitYVector = new Vector2(0f, 1f);

		public float X;

		public float Y;

		public static Vector2 Zero => zeroVector;

		public static Vector2 One => unitVector;

		public static Vector2 UnitX => unitXVector;

		public static Vector2 UnitY => unitYVector;

		/// <summary>
		/// Constructor foe standard 2D vector.
		/// </summary>
		/// <param name="x">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="y">
		/// A <see cref="T:System.Single" />
		/// </param>
		public Vector2(float x, float y)
		{
			X = x;
			Y = y;
		}

		/// <summary>
		/// Constructor for "square" vector.
		/// </summary>
		/// <param name="value">
		/// A <see cref="T:System.Single" />
		/// </param>
		public Vector2(float value)
		{
			X = value;
			Y = value;
		}

		public static void Reflect(ref Vector2 vector, ref Vector2 normal, out Vector2 result)
		{
			float num = Dot(vector, normal);
			result.X = vector.X - 2f * num * normal.X;
			result.Y = vector.Y - 2f * num * normal.Y;
		}

		public static Vector2 Reflect(Vector2 vector, Vector2 normal)
		{
			Reflect(ref vector, ref normal, out var result);
			return result;
		}

		public static Vector2 Add(Vector2 value1, Vector2 value2)
		{
			value1.X += value2.X;
			value1.Y += value2.Y;
			return value1;
		}

		public static void Add(ref Vector2 value1, ref Vector2 value2, out Vector2 result)
		{
			result.X = value1.X + value2.X;
			result.Y = value1.Y + value2.Y;
		}

		public static Vector2 Barycentric(Vector2 value1, Vector2 value2, Vector2 value3, float amount1, float amount2)
		{
			return new Vector2(MathHelper.Barycentric(value1.X, value2.X, value3.X, amount1, amount2), MathHelper.Barycentric(value1.Y, value2.Y, value3.Y, amount1, amount2));
		}

		public static void Barycentric(ref Vector2 value1, ref Vector2 value2, ref Vector2 value3, float amount1, float amount2, out Vector2 result)
		{
			result = new Vector2(MathHelper.Barycentric(value1.X, value2.X, value3.X, amount1, amount2), MathHelper.Barycentric(value1.Y, value2.Y, value3.Y, amount1, amount2));
		}

		public static Vector2 CatmullRom(Vector2 value1, Vector2 value2, Vector2 value3, Vector2 value4, float amount)
		{
			return new Vector2(MathHelper.CatmullRom(value1.X, value2.X, value3.X, value4.X, amount), MathHelper.CatmullRom(value1.Y, value2.Y, value3.Y, value4.Y, amount));
		}

		public static void CatmullRom(ref Vector2 value1, ref Vector2 value2, ref Vector2 value3, ref Vector2 value4, float amount, out Vector2 result)
		{
			result = new Vector2(MathHelper.CatmullRom(value1.X, value2.X, value3.X, value4.X, amount), MathHelper.CatmullRom(value1.Y, value2.Y, value3.Y, value4.Y, amount));
		}

		public static Vector2 Clamp(Vector2 value1, Vector2 min, Vector2 max)
		{
			return new Vector2(MathHelper.Clamp(value1.X, min.X, max.X), MathHelper.Clamp(value1.Y, min.Y, max.Y));
		}

		public static void Clamp(ref Vector2 value1, ref Vector2 min, ref Vector2 max, out Vector2 result)
		{
			result = new Vector2(MathHelper.Clamp(value1.X, min.X, max.X), MathHelper.Clamp(value1.Y, min.Y, max.Y));
		}

		/// <summary>
		/// Returns float precison distanve between two vectors
		/// </summary>
		/// <param name="value1">
		/// A <see cref="T:Microsoft.Xna.Framework.Vector2" />
		/// </param>
		/// <param name="value2">
		/// A <see cref="T:Microsoft.Xna.Framework.Vector2" />
		/// </param>
		/// <returns>
		/// A <see cref="T:System.Single" />
		/// </returns>
		public static float Distance(Vector2 value1, Vector2 value2)
		{
			DistanceSquared(ref value1, ref value2, out var result);
			return (float)Math.Sqrt(result);
		}

		public static void Distance(ref Vector2 value1, ref Vector2 value2, out float result)
		{
			DistanceSquared(ref value1, ref value2, out result);
			result = (float)Math.Sqrt(result);
		}

		public static float DistanceSquared(Vector2 value1, Vector2 value2)
		{
			DistanceSquared(ref value1, ref value2, out var result);
			return result;
		}

		public static void DistanceSquared(ref Vector2 value1, ref Vector2 value2, out float result)
		{
			result = (value1.X - value2.X) * (value1.X - value2.X) + (value1.Y - value2.Y) * (value1.Y - value2.Y);
		}

		/// <summary>
		/// Devide first vector with the secund vector
		/// </summary>
		/// <param name="value1">
		/// A <see cref="T:Microsoft.Xna.Framework.Vector2" />
		/// </param>
		/// <param name="value2">
		/// A <see cref="T:Microsoft.Xna.Framework.Vector2" />
		/// </param>
		/// <returns>
		/// A <see cref="T:Microsoft.Xna.Framework.Vector2" />
		/// </returns>
		public static Vector2 Divide(Vector2 value1, Vector2 value2)
		{
			value1.X /= value2.X;
			value1.Y /= value2.Y;
			return value1;
		}

		public static void Divide(ref Vector2 value1, ref Vector2 value2, out Vector2 result)
		{
			result.X = value1.X / value2.X;
			result.Y = value1.Y / value2.Y;
		}

		public static Vector2 Divide(Vector2 value1, float divider)
		{
			float num = 1f / divider;
			value1.X *= num;
			value1.Y *= num;
			return value1;
		}

		public static void Divide(ref Vector2 value1, float divider, out Vector2 result)
		{
			float num = 1f / divider;
			result.X = value1.X * num;
			result.Y = value1.Y * num;
		}

		public static float Dot(Vector2 value1, Vector2 value2)
		{
			return value1.X * value2.X + value1.Y * value2.Y;
		}

		public static void Dot(ref Vector2 value1, ref Vector2 value2, out float result)
		{
			result = value1.X * value2.X + value1.Y * value2.Y;
		}

		public override bool Equals(object obj)
		{
			if (!(obj is Vector2))
			{
				return false;
			}
			return this == (Vector2)obj;
		}

		public bool Equals(Vector2 other)
		{
			return this == other;
		}

		public override int GetHashCode()
		{
			return (int)(X + Y);
		}

		public static Vector2 Hermite(Vector2 value1, Vector2 tangent1, Vector2 value2, Vector2 tangent2, float amount)
		{
			Vector2 result = default(Vector2);
			Hermite(ref value1, ref tangent1, ref value2, ref tangent2, amount, out result);
			return result;
		}

		public static void Hermite(ref Vector2 value1, ref Vector2 tangent1, ref Vector2 value2, ref Vector2 tangent2, float amount, out Vector2 result)
		{
			result.X = MathHelper.Hermite(value1.X, tangent1.X, value2.X, tangent2.X, amount);
			result.Y = MathHelper.Hermite(value1.Y, tangent1.Y, value2.Y, tangent2.Y, amount);
		}

		public float Length()
		{
			DistanceSquared(ref this, ref zeroVector, out var result);
			return (float)Math.Sqrt(result);
		}

		public float LengthSquared()
		{
			DistanceSquared(ref this, ref zeroVector, out var result);
			return result;
		}

		public static Vector2 Lerp(Vector2 value1, Vector2 value2, float amount)
		{
			return new Vector2(MathHelper.Lerp(value1.X, value2.X, amount), MathHelper.Lerp(value1.Y, value2.Y, amount));
		}

		public static void Lerp(ref Vector2 value1, ref Vector2 value2, float amount, out Vector2 result)
		{
			result = new Vector2(MathHelper.Lerp(value1.X, value2.X, amount), MathHelper.Lerp(value1.Y, value2.Y, amount));
		}

		public static Vector2 Max(Vector2 value1, Vector2 value2)
		{
			return new Vector2(MathHelper.Max(value1.X, value2.X), MathHelper.Max(value1.Y, value2.Y));
		}

		public static void Max(ref Vector2 value1, ref Vector2 value2, out Vector2 result)
		{
			result = new Vector2(MathHelper.Max(value1.X, value2.X), MathHelper.Max(value1.Y, value2.Y));
		}

		public static Vector2 Min(Vector2 value1, Vector2 value2)
		{
			return new Vector2(MathHelper.Min(value1.X, value2.X), MathHelper.Min(value1.Y, value2.Y));
		}

		public static void Min(ref Vector2 value1, ref Vector2 value2, out Vector2 result)
		{
			result = new Vector2(MathHelper.Min(value1.X, value2.X), MathHelper.Min(value1.Y, value2.Y));
		}

		public static Vector2 Multiply(Vector2 value1, Vector2 value2)
		{
			value1.X *= value2.X;
			value1.Y *= value2.Y;
			return value1;
		}

		public static Vector2 Multiply(Vector2 value1, float scaleFactor)
		{
			value1.X *= scaleFactor;
			value1.Y *= scaleFactor;
			return value1;
		}

		public static void Multiply(ref Vector2 value1, float scaleFactor, out Vector2 result)
		{
			result.X = value1.X * scaleFactor;
			result.Y = value1.Y * scaleFactor;
		}

		public static void Multiply(ref Vector2 value1, ref Vector2 value2, out Vector2 result)
		{
			result.X = value1.X * value2.X;
			result.Y = value1.Y * value2.Y;
		}

		public static Vector2 Negate(Vector2 value)
		{
			value.X = 0f - value.X;
			value.Y = 0f - value.Y;
			return value;
		}

		public static void Negate(ref Vector2 value, out Vector2 result)
		{
			result.X = 0f - value.X;
			result.Y = 0f - value.Y;
		}

		public void Normalize()
		{
			Normalize(ref this, out this);
		}

		public static Vector2 Normalize(Vector2 value)
		{
			Normalize(ref value, out value);
			return value;
		}

		public static void Normalize(ref Vector2 value, out Vector2 result)
		{
			DistanceSquared(ref value, ref zeroVector, out var result2);
			result2 = 1f / (float)Math.Sqrt(result2);
			result.X = value.X * result2;
			result.Y = value.Y * result2;
		}

		public static Vector2 SmoothStep(Vector2 value1, Vector2 value2, float amount)
		{
			return new Vector2(MathHelper.SmoothStep(value1.X, value2.X, amount), MathHelper.SmoothStep(value1.Y, value2.Y, amount));
		}

		public static void SmoothStep(ref Vector2 value1, ref Vector2 value2, float amount, out Vector2 result)
		{
			result = new Vector2(MathHelper.SmoothStep(value1.X, value2.X, amount), MathHelper.SmoothStep(value1.Y, value2.Y, amount));
		}

		public static Vector2 Subtract(Vector2 value1, Vector2 value2)
		{
			value1.X -= value2.X;
			value1.Y -= value2.Y;
			return value1;
		}

		public static void Subtract(ref Vector2 value1, ref Vector2 value2, out Vector2 result)
		{
			result.X = value1.X - value2.X;
			result.Y = value1.Y - value2.Y;
		}

		public static Vector2 Transform(Vector2 position, Matrix matrix)
		{
			Transform(ref position, ref matrix, out position);
			return position;
		}

		public static void Transform(ref Vector2 position, ref Matrix matrix, out Vector2 result)
		{
			result = new Vector2(position.X * matrix.M11 + position.Y * matrix.M21 + matrix.M41, position.X * matrix.M12 + position.Y * matrix.M22 + matrix.M42);
		}

		public static void Transform(Vector2[] sourceArray, ref Matrix matrix, Vector2[] destinationArray)
		{
			throw new NotImplementedException();
		}

		public static void Transform(Vector2[] sourceArray, int sourceIndex, ref Matrix matrix, Vector2[] destinationArray, int destinationIndex, int length)
		{
			throw new NotImplementedException();
		}

		public static Vector2 TransformNormal(Vector2 normal, Matrix matrix)
		{
			TransformNormal(ref normal, ref matrix, out normal);
			return normal;
		}

		public static void TransformNormal(ref Vector2 normal, ref Matrix matrix, out Vector2 result)
		{
			result = new Vector2(normal.X * matrix.M11 + normal.Y * matrix.M21, normal.X * matrix.M12 + normal.Y * matrix.M22);
		}

		public static void TransformNormal(Vector2[] sourceArray, ref Matrix matrix, Vector2[] destinationArray)
		{
			throw new NotImplementedException();
		}

		public static void TransformNormal(Vector2[] sourceArray, int sourceIndex, ref Matrix matrix, Vector2[] destinationArray, int destinationIndex, int length)
		{
			throw new NotImplementedException();
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder(24);
			stringBuilder.Append("{X:");
			stringBuilder.Append(X);
			stringBuilder.Append(" Y:");
			stringBuilder.Append(Y);
			stringBuilder.Append("}");
			return stringBuilder.ToString();
		}

		public static Vector2 operator -(Vector2 value)
		{
			value.X = 0f - value.X;
			value.Y = 0f - value.Y;
			return value;
		}

		public static bool operator ==(Vector2 value1, Vector2 value2)
		{
			if (value1.X == value2.X)
			{
				return value1.Y == value2.Y;
			}
			return false;
		}

		public static bool operator !=(Vector2 value1, Vector2 value2)
		{
			if (value1.X == value2.X)
			{
				return value1.Y != value2.Y;
			}
			return true;
		}

		public static Vector2 operator +(Vector2 value1, Vector2 value2)
		{
			value1.X += value2.X;
			value1.Y += value2.Y;
			return value1;
		}

		public static Vector2 operator -(Vector2 value1, Vector2 value2)
		{
			value1.X -= value2.X;
			value1.Y -= value2.Y;
			return value1;
		}

		public static Vector2 operator *(Vector2 value1, Vector2 value2)
		{
			value1.X *= value2.X;
			value1.Y *= value2.Y;
			return value1;
		}

		public static Vector2 operator *(Vector2 value, float scaleFactor)
		{
			value.X *= scaleFactor;
			value.Y *= scaleFactor;
			return value;
		}

		public static Vector2 operator *(float scaleFactor, Vector2 value)
		{
			value.X *= scaleFactor;
			value.Y *= scaleFactor;
			return value;
		}

		public static Vector2 operator /(Vector2 value1, Vector2 value2)
		{
			value1.X /= value2.X;
			value1.Y /= value2.Y;
			return value1;
		}

		public static Vector2 operator /(Vector2 value1, float divider)
		{
			float num = 1f / divider;
			value1.X *= num;
			value1.Y *= num;
			return value1;
		}
	}
}
