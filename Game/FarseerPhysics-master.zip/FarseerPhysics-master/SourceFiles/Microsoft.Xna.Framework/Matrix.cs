using System;

namespace Microsoft.Xna.Framework
{
	public struct Matrix : IEquatable<Matrix>
	{
		public float M11;

		public float M12;

		public float M13;

		public float M14;

		public float M21;

		public float M22;

		public float M23;

		public float M24;

		public float M31;

		public float M32;

		public float M33;

		public float M34;

		public float M41;

		public float M42;

		public float M43;

		public float M44;

		private static Matrix identity = new Matrix(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f);

		public static Matrix Identity => identity;

		public Vector3 Backward
		{
			get
			{
				return new Vector3(M31, M32, M33);
			}
			set
			{
				M31 = value.X;
				M32 = value.Y;
				M33 = value.Z;
			}
		}

		public Vector3 Down
		{
			get
			{
				return new Vector3(0f - M21, 0f - M22, 0f - M23);
			}
			set
			{
				M21 = 0f - value.X;
				M22 = 0f - value.Y;
				M23 = 0f - value.Z;
			}
		}

		public Vector3 Forward
		{
			get
			{
				return new Vector3(0f - M31, 0f - M32, 0f - M33);
			}
			set
			{
				M31 = 0f - value.X;
				M32 = 0f - value.Y;
				M33 = 0f - value.Z;
			}
		}

		public Vector3 Left
		{
			get
			{
				return new Vector3(0f - M11, 0f - M12, 0f - M13);
			}
			set
			{
				M11 = 0f - value.X;
				M12 = 0f - value.Y;
				M13 = 0f - value.Z;
			}
		}

		public Vector3 Right
		{
			get
			{
				return new Vector3(M11, M12, M13);
			}
			set
			{
				M11 = value.X;
				M12 = value.Y;
				M13 = value.Z;
			}
		}

		public Vector3 Translation
		{
			get
			{
				return new Vector3(M41, M42, M43);
			}
			set
			{
				M41 = value.X;
				M42 = value.Y;
				M43 = value.Z;
			}
		}

		public Vector3 Up
		{
			get
			{
				return new Vector3(M21, M22, M23);
			}
			set
			{
				M21 = value.X;
				M22 = value.Y;
				M23 = value.Z;
			}
		}

		/// <summary>
		/// Constructor for 4x4 Matrix
		/// </summary>
		/// <param name="m11">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m12">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m13">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m14">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m21">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m22">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m23">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m24">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m31">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m32">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m33">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m34">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m41">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m42">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m43">
		/// A <see cref="T:System.Single" />
		/// </param>
		/// <param name="m44">
		/// A <see cref="T:System.Single" />
		/// </param>
		public Matrix(float m11, float m12, float m13, float m14, float m21, float m22, float m23, float m24, float m31, float m32, float m33, float m34, float m41, float m42, float m43, float m44)
		{
			M11 = m11;
			M12 = m12;
			M13 = m13;
			M14 = m14;
			M21 = m21;
			M22 = m22;
			M23 = m23;
			M24 = m24;
			M31 = m31;
			M32 = m32;
			M33 = m33;
			M34 = m34;
			M41 = m41;
			M42 = m42;
			M43 = m43;
			M44 = m44;
		}

		public static Matrix CreateWorld(Vector3 position, Vector3 forward, Vector3 up)
		{
			CreateWorld(ref position, ref forward, ref up, out var result);
			return result;
		}

		public static void CreateWorld(ref Vector3 position, ref Vector3 forward, ref Vector3 up, out Matrix result)
		{
			Vector3.Normalize(ref forward, out var result2);
			Vector3.Cross(ref forward, ref up, out var result3);
			Vector3.Cross(ref result3, ref forward, out var result4);
			result3.Normalize();
			result4.Normalize();
			result = default(Matrix);
			result.Right = result3;
			result.Up = result4;
			result.Forward = result2;
			result.Translation = position;
			result.M44 = 1f;
		}

		/// <summary>
		/// Adds second matrix to the first.
		/// </summary>
		/// <param name="matrix1">
		/// A <see cref="T:Microsoft.Xna.Framework.Matrix" />
		/// </param>
		/// <param name="matrix2">
		/// A <see cref="T:Microsoft.Xna.Framework.Matrix" />
		/// </param>
		/// <returns>
		/// A <see cref="T:Microsoft.Xna.Framework.Matrix" />
		/// </returns>
		public static Matrix Add(Matrix matrix1, Matrix matrix2)
		{
			matrix1.M11 += matrix2.M11;
			matrix1.M12 += matrix2.M12;
			matrix1.M13 += matrix2.M13;
			matrix1.M14 += matrix2.M14;
			matrix1.M21 += matrix2.M21;
			matrix1.M22 += matrix2.M22;
			matrix1.M23 += matrix2.M23;
			matrix1.M24 += matrix2.M24;
			matrix1.M31 += matrix2.M31;
			matrix1.M32 += matrix2.M32;
			matrix1.M33 += matrix2.M33;
			matrix1.M34 += matrix2.M34;
			matrix1.M41 += matrix2.M41;
			matrix1.M42 += matrix2.M42;
			matrix1.M43 += matrix2.M43;
			matrix1.M44 += matrix2.M44;
			return matrix1;
		}

		/// <summary>
		/// Adds two Matrix and save to the result Matrix
		/// </summary>
		/// <param name="matrix1">
		/// A <see cref="T:Microsoft.Xna.Framework.Matrix" />
		/// </param>
		/// <param name="matrix2">
		/// A <see cref="T:Microsoft.Xna.Framework.Matrix" />
		/// </param>
		/// <param name="result">
		/// A <see cref="T:Microsoft.Xna.Framework.Matrix" />
		/// </param>
		public static void Add(ref Matrix matrix1, ref Matrix matrix2, out Matrix result)
		{
			result.M11 = matrix1.M11 + matrix2.M11;
			result.M12 = matrix1.M12 + matrix2.M12;
			result.M13 = matrix1.M13 + matrix2.M13;
			result.M14 = matrix1.M14 + matrix2.M14;
			result.M21 = matrix1.M21 + matrix2.M21;
			result.M22 = matrix1.M22 + matrix2.M22;
			result.M23 = matrix1.M23 + matrix2.M23;
			result.M24 = matrix1.M24 + matrix2.M24;
			result.M31 = matrix1.M31 + matrix2.M31;
			result.M32 = matrix1.M32 + matrix2.M32;
			result.M33 = matrix1.M33 + matrix2.M33;
			result.M34 = matrix1.M34 + matrix2.M34;
			result.M41 = matrix1.M41 + matrix2.M41;
			result.M42 = matrix1.M42 + matrix2.M42;
			result.M43 = matrix1.M43 + matrix2.M43;
			result.M44 = matrix1.M44 + matrix2.M44;
		}

		public static Matrix CreateBillboard(Vector3 objectPosition, Vector3 cameraPosition, Vector3 cameraUpVector, Vector3? cameraForwardVector)
		{
			CreateBillboard(ref objectPosition, ref cameraPosition, ref cameraUpVector, cameraForwardVector, out var result);
			return result;
		}

		public static void CreateBillboard(ref Vector3 objectPosition, ref Vector3 cameraPosition, ref Vector3 cameraUpVector, Vector3? cameraForwardVector, out Matrix result)
		{
			Vector3 value = objectPosition - cameraPosition;
			Vector3.Normalize(ref value, out var result2);
			Vector3.Normalize(ref cameraUpVector, out var result3);
			Vector3.Cross(ref result2, ref result3, out var result4);
			Vector3.Cross(ref result2, ref result4, out result3);
			result = Identity;
			result.Backward = result2;
			result.Right = result4;
			result.Up = result3;
			result.Translation = value;
		}

		public static Matrix CreateConstrainedBillboard(Vector3 objectPosition, Vector3 cameraPosition, Vector3 rotateAxis, Vector3? cameraForwardVector, Vector3? objectForwardVector)
		{
			throw new NotImplementedException();
		}

		public static void CreateConstrainedBillboard(ref Vector3 objectPosition, ref Vector3 cameraPosition, ref Vector3 rotateAxis, Vector3? cameraForwardVector, Vector3? objectForwardVector, out Matrix result)
		{
			throw new NotImplementedException();
		}

		public static Matrix CreateFromAxisAngle(Vector3 axis, float angle)
		{
			throw new NotImplementedException();
		}

		public static void CreateFromAxisAngle(ref Vector3 axis, float angle, out Matrix result)
		{
			throw new NotImplementedException();
		}

		public static Matrix CreateLookAt(Vector3 cameraPosition, Vector3 cameraTarget, Vector3 cameraUpVector)
		{
			CreateLookAt(ref cameraPosition, ref cameraTarget, ref cameraUpVector, out var result);
			return result;
		}

		public static void CreateLookAt(ref Vector3 cameraPosition, ref Vector3 cameraTarget, ref Vector3 cameraUpVector, out Matrix result)
		{
			Vector3 vector = Vector3.Normalize(cameraPosition - cameraTarget);
			Vector3 vector2 = Vector3.Normalize(Vector3.Cross(cameraUpVector, vector));
			Vector3 vector3 = Vector3.Cross(vector, vector2);
			result = Identity;
			result.M11 = vector2.X;
			result.M12 = vector3.X;
			result.M13 = vector.X;
			result.M21 = vector2.Y;
			result.M22 = vector3.Y;
			result.M23 = vector.Y;
			result.M31 = vector2.Z;
			result.M32 = vector3.Z;
			result.M33 = vector.Z;
			result.M41 = 0f - Vector3.Dot(vector2, cameraPosition);
			result.M42 = 0f - Vector3.Dot(vector3, cameraPosition);
			result.M43 = 0f - Vector3.Dot(vector, cameraPosition);
		}

		public static Matrix CreateOrthographic(float width, float height, float zNearPlane, float zFarPlane)
		{
			CreateOrthographic(width, height, zNearPlane, zFarPlane, out var result);
			return result;
		}

		public static void CreateOrthographic(float width, float height, float zNearPlane, float zFarPlane, out Matrix result)
		{
			result.M11 = 2f / width;
			result.M12 = 0f;
			result.M13 = 0f;
			result.M14 = 0f;
			result.M21 = 0f;
			result.M22 = 2f / height;
			result.M23 = 0f;
			result.M24 = 0f;
			result.M31 = 0f;
			result.M32 = 0f;
			result.M33 = 1f / (zNearPlane - zFarPlane);
			result.M34 = 0f;
			result.M41 = 0f;
			result.M42 = 0f;
			result.M43 = zNearPlane / (zNearPlane - zFarPlane);
			result.M44 = 1f;
		}

		public static Matrix CreateOrthographicOffCenter(float left, float right, float bottom, float top, float zNearPlane, float zFarPlane)
		{
			CreateOrthographicOffCenter(left, right, bottom, top, zNearPlane, zFarPlane, out var result);
			return result;
		}

		public static void CreateOrthographicOffCenter(float left, float right, float bottom, float top, float zNearPlane, float zFarPlane, out Matrix result)
		{
			result.M11 = 2f / (right - left);
			result.M12 = 0f;
			result.M13 = 0f;
			result.M14 = 0f;
			result.M21 = 0f;
			result.M22 = 2f / (top - bottom);
			result.M23 = 0f;
			result.M24 = 0f;
			result.M31 = 0f;
			result.M32 = 0f;
			result.M33 = 1f / (zNearPlane - zFarPlane);
			result.M34 = 0f;
			result.M41 = (left + right) / (left - right);
			result.M42 = (bottom + top) / (bottom - top);
			result.M43 = zNearPlane / (zNearPlane - zFarPlane);
			result.M44 = 1f;
		}

		public static Matrix CreatePerspective(float width, float height, float zNearPlane, float zFarPlane)
		{
			throw new NotImplementedException();
		}

		public static void CreatePerspective(float width, float height, float zNearPlane, float zFarPlane, out Matrix result)
		{
			throw new NotImplementedException();
		}

		public static Matrix CreatePerspectiveFieldOfView(float fieldOfView, float aspectRatio, float nearPlaneDistance, float farPlaneDistance)
		{
			CreatePerspectiveFieldOfView(fieldOfView, aspectRatio, nearPlaneDistance, farPlaneDistance, out var result);
			return result;
		}

		public static void CreatePerspectiveFieldOfView(float fieldOfView, float aspectRatio, float nearPlaneDistance, float farPlaneDistance, out Matrix result)
		{
			result = new Matrix(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f);
			if (fieldOfView < 0f || fieldOfView > 3.1415925f)
			{
				throw new ArgumentOutOfRangeException("fieldOfView", "fieldOfView takes a value between 0 and Pi (180 degrees) in radians.");
			}
			if (nearPlaneDistance <= 0f)
			{
				throw new ArgumentOutOfRangeException("nearPlaneDistance", "You should specify positive value for nearPlaneDistance.");
			}
			if (farPlaneDistance <= 0f)
			{
				throw new ArgumentOutOfRangeException("farPlaneDistance", "You should specify positive value for farPlaneDistance.");
			}
			if (farPlaneDistance <= nearPlaneDistance)
			{
				throw new ArgumentOutOfRangeException("nearPlaneDistance", "Near plane distance is larger than Far plane distance. Near plane distance must be smaller than Far plane distance.");
			}
			float num = 1f / (float)Math.Tan(fieldOfView / 2f);
			float m = num / aspectRatio;
			result.M11 = m;
			result.M22 = num;
			result.M33 = farPlaneDistance / (nearPlaneDistance - farPlaneDistance);
			result.M34 = -1f;
			result.M43 = nearPlaneDistance * farPlaneDistance / (nearPlaneDistance - farPlaneDistance);
		}

		public static Matrix CreatePerspectiveOffCenter(float left, float right, float bottom, float top, float zNearPlane, float zFarPlane)
		{
			throw new NotImplementedException();
		}

		public static void CreatePerspectiveOffCenter(float left, float right, float bottom, float top, float nearPlaneDistance, float farPlaneDistance, out Matrix result)
		{
			throw new NotImplementedException();
		}

		public static Matrix CreateRotationX(float radians)
		{
			Matrix result = Identity;
			result.M22 = (float)Math.Cos(radians);
			result.M23 = (float)Math.Sin(radians);
			result.M32 = 0f - result.M23;
			result.M33 = result.M22;
			return result;
		}

		public static void CreateRotationX(float radians, out Matrix result)
		{
			result = Identity;
			result.M22 = (float)Math.Cos(radians);
			result.M23 = (float)Math.Sin(radians);
			result.M32 = 0f - result.M23;
			result.M33 = result.M22;
		}

		public static Matrix CreateRotationY(float radians)
		{
			Matrix result = Identity;
			result.M11 = (float)Math.Cos(radians);
			result.M13 = (float)Math.Sin(radians);
			result.M31 = 0f - result.M13;
			result.M33 = result.M11;
			return result;
		}

		public static void CreateRotationY(float radians, out Matrix result)
		{
			result = Identity;
			result.M11 = (float)Math.Cos(radians);
			result.M13 = (float)Math.Sin(radians);
			result.M31 = 0f - result.M13;
			result.M33 = result.M11;
		}

		public static Matrix CreateRotationZ(float radians)
		{
			Matrix result = Identity;
			result.M11 = (float)Math.Cos(radians);
			result.M12 = (float)Math.Sin(radians);
			result.M21 = 0f - result.M12;
			result.M22 = result.M11;
			return result;
		}

		public static void CreateRotationZ(float radians, out Matrix result)
		{
			result = Identity;
			result.M11 = (float)Math.Cos(radians);
			result.M12 = (float)Math.Sin(radians);
			result.M21 = 0f - result.M12;
			result.M22 = result.M11;
		}

		public static Matrix CreateScale(float scale)
		{
			Matrix result = Identity;
			result.M11 = scale;
			result.M22 = scale;
			result.M33 = scale;
			return result;
		}

		public static void CreateScale(float scale, out Matrix result)
		{
			result = Identity;
			result.M11 = scale;
			result.M22 = scale;
			result.M33 = scale;
		}

		public static Matrix CreateScale(float xScale, float yScale, float zScale)
		{
			Matrix result = Identity;
			result.M11 = xScale;
			result.M22 = yScale;
			result.M33 = zScale;
			return result;
		}

		public static void CreateScale(float xScale, float yScale, float zScale, out Matrix result)
		{
			result = Identity;
			result.M11 = xScale;
			result.M22 = yScale;
			result.M33 = zScale;
		}

		public static Matrix CreateScale(Vector3 scales)
		{
			Matrix result = Identity;
			result.M11 = scales.X;
			result.M22 = scales.Y;
			result.M33 = scales.Z;
			return result;
		}

		public static void CreateScale(ref Vector3 scales, out Matrix result)
		{
			result = Identity;
			result.M11 = scales.X;
			result.M22 = scales.Y;
			result.M33 = scales.Z;
		}

		public static Matrix CreateTranslation(float xPosition, float yPosition, float zPosition)
		{
			Matrix result = Identity;
			result.M41 = xPosition;
			result.M42 = yPosition;
			result.M43 = zPosition;
			return result;
		}

		public static void CreateTranslation(float xPosition, float yPosition, float zPosition, out Matrix result)
		{
			result = Identity;
			result.M41 = xPosition;
			result.M42 = yPosition;
			result.M43 = zPosition;
		}

		public static Matrix CreateTranslation(Vector3 position)
		{
			Matrix result = Identity;
			result.M41 = position.X;
			result.M42 = position.Y;
			result.M43 = position.Z;
			return result;
		}

		public static void CreateTranslation(ref Vector3 position, out Matrix result)
		{
			result = Identity;
			result.M41 = position.X;
			result.M42 = position.Y;
			result.M43 = position.Z;
		}

		public static Matrix Divide(Matrix matrix1, Matrix matrix2)
		{
			Divide(ref matrix1, ref matrix2, out var result);
			return result;
		}

		public static void Divide(ref Matrix matrix1, ref Matrix matrix2, out Matrix result)
		{
			Matrix matrix3 = Invert(matrix2);
			Multiply(ref matrix1, ref matrix3, out result);
		}

		public static Matrix Divide(Matrix matrix1, float divider)
		{
			Divide(ref matrix1, divider, out var result);
			return result;
		}

		public static void Divide(ref Matrix matrix1, float divider, out Matrix result)
		{
			float factor = 1f / divider;
			Multiply(ref matrix1, factor, out result);
		}

		public static Matrix Invert(Matrix matrix)
		{
			Invert(ref matrix, out matrix);
			return matrix;
		}

		public static void Invert(ref Matrix matrix, out Matrix result)
		{
			float num = matrix.M11 * matrix.M22 - matrix.M12 * matrix.M21;
			float num2 = matrix.M11 * matrix.M23 - matrix.M13 * matrix.M21;
			float num3 = matrix.M11 * matrix.M24 - matrix.M14 * matrix.M21;
			float num4 = matrix.M12 * matrix.M23 - matrix.M13 * matrix.M22;
			float num5 = matrix.M12 * matrix.M24 - matrix.M14 * matrix.M22;
			float num6 = matrix.M13 * matrix.M24 - matrix.M14 * matrix.M23;
			float num7 = matrix.M31 * matrix.M42 - matrix.M32 * matrix.M41;
			float num8 = matrix.M31 * matrix.M43 - matrix.M33 * matrix.M41;
			float num9 = matrix.M31 * matrix.M44 - matrix.M34 * matrix.M41;
			float num10 = matrix.M32 * matrix.M43 - matrix.M33 * matrix.M42;
			float num11 = matrix.M32 * matrix.M44 - matrix.M34 * matrix.M42;
			float num12 = matrix.M33 * matrix.M44 - matrix.M34 * matrix.M43;
			float num13 = num * num12 - num2 * num11 + num3 * num10 + num4 * num9 - num5 * num8 + num6 * num7;
			float num14 = 1f / num13;
			Matrix matrix2 = default(Matrix);
			matrix2.M11 = (matrix.M22 * num12 - matrix.M23 * num11 + matrix.M24 * num10) * num14;
			matrix2.M12 = ((0f - matrix.M12) * num12 + matrix.M13 * num11 - matrix.M14 * num10) * num14;
			matrix2.M13 = (matrix.M42 * num6 - matrix.M43 * num5 + matrix.M44 * num4) * num14;
			matrix2.M14 = ((0f - matrix.M32) * num6 + matrix.M33 * num5 - matrix.M34 * num4) * num14;
			matrix2.M21 = ((0f - matrix.M21) * num12 + matrix.M23 * num9 - matrix.M24 * num8) * num14;
			matrix2.M22 = (matrix.M11 * num12 - matrix.M13 * num9 + matrix.M14 * num8) * num14;
			matrix2.M23 = ((0f - matrix.M41) * num6 + matrix.M43 * num3 - matrix.M44 * num2) * num14;
			matrix2.M24 = (matrix.M31 * num6 - matrix.M33 * num3 + matrix.M34 * num2) * num14;
			matrix2.M31 = (matrix.M21 * num11 - matrix.M22 * num9 + matrix.M24 * num7) * num14;
			matrix2.M32 = ((0f - matrix.M11) * num11 + matrix.M12 * num9 - matrix.M14 * num7) * num14;
			matrix2.M33 = (matrix.M41 * num5 - matrix.M42 * num3 + matrix.M44 * num) * num14;
			matrix2.M34 = ((0f - matrix.M31) * num5 + matrix.M32 * num3 - matrix.M34 * num) * num14;
			matrix2.M41 = ((0f - matrix.M21) * num10 + matrix.M22 * num8 - matrix.M23 * num7) * num14;
			matrix2.M42 = (matrix.M11 * num10 - matrix.M12 * num8 + matrix.M13 * num7) * num14;
			matrix2.M43 = ((0f - matrix.M41) * num4 + matrix.M42 * num2 - matrix.M43 * num) * num14;
			matrix2.M44 = (matrix.M31 * num4 - matrix.M32 * num2 + matrix.M33 * num) * num14;
			result = matrix2;
		}

		public static Matrix Lerp(Matrix matrix1, Matrix matrix2, float amount)
		{
			throw new NotImplementedException();
		}

		public static void Lerp(ref Matrix matrix1, ref Matrix matrix2, float amount, out Matrix result)
		{
			throw new NotImplementedException();
		}

		public static Matrix Multiply(Matrix matrix1, Matrix matrix2)
		{
			Multiply(ref matrix1, ref matrix2, out var result);
			return result;
		}

		public static void Multiply(ref Matrix matrix1, ref Matrix matrix2, out Matrix result)
		{
			result.M11 = matrix1.M11 * matrix2.M11 + matrix1.M12 * matrix2.M21 + matrix1.M13 * matrix2.M31 + matrix1.M14 * matrix2.M41;
			result.M12 = matrix1.M11 * matrix2.M12 + matrix1.M12 * matrix2.M22 + matrix1.M13 * matrix2.M32 + matrix1.M14 * matrix2.M42;
			result.M13 = matrix1.M11 * matrix2.M13 + matrix1.M12 * matrix2.M23 + matrix1.M13 * matrix2.M33 + matrix1.M14 * matrix2.M43;
			result.M14 = matrix1.M11 * matrix2.M14 + matrix1.M12 * matrix2.M24 + matrix1.M13 * matrix2.M34 + matrix1.M14 * matrix2.M44;
			result.M21 = matrix1.M21 * matrix2.M11 + matrix1.M22 * matrix2.M21 + matrix1.M23 * matrix2.M31 + matrix1.M24 * matrix2.M41;
			result.M22 = matrix1.M21 * matrix2.M12 + matrix1.M22 * matrix2.M22 + matrix1.M23 * matrix2.M32 + matrix1.M24 * matrix2.M42;
			result.M23 = matrix1.M21 * matrix2.M13 + matrix1.M22 * matrix2.M23 + matrix1.M23 * matrix2.M33 + matrix1.M24 * matrix2.M43;
			result.M24 = matrix1.M21 * matrix2.M14 + matrix1.M22 * matrix2.M24 + matrix1.M23 * matrix2.M34 + matrix1.M24 * matrix2.M44;
			result.M31 = matrix1.M31 * matrix2.M11 + matrix1.M32 * matrix2.M21 + matrix1.M33 * matrix2.M31 + matrix1.M34 * matrix2.M41;
			result.M32 = matrix1.M31 * matrix2.M12 + matrix1.M32 * matrix2.M22 + matrix1.M33 * matrix2.M32 + matrix1.M34 * matrix2.M42;
			result.M33 = matrix1.M31 * matrix2.M13 + matrix1.M32 * matrix2.M23 + matrix1.M33 * matrix2.M33 + matrix1.M34 * matrix2.M43;
			result.M34 = matrix1.M31 * matrix2.M14 + matrix1.M32 * matrix2.M24 + matrix1.M33 * matrix2.M34 + matrix1.M34 * matrix2.M44;
			result.M41 = matrix1.M41 * matrix2.M11 + matrix1.M42 * matrix2.M21 + matrix1.M43 * matrix2.M31 + matrix1.M44 * matrix2.M41;
			result.M42 = matrix1.M41 * matrix2.M12 + matrix1.M42 * matrix2.M22 + matrix1.M43 * matrix2.M32 + matrix1.M44 * matrix2.M42;
			result.M43 = matrix1.M41 * matrix2.M13 + matrix1.M42 * matrix2.M23 + matrix1.M43 * matrix2.M33 + matrix1.M44 * matrix2.M43;
			result.M44 = matrix1.M41 * matrix2.M14 + matrix1.M42 * matrix2.M24 + matrix1.M43 * matrix2.M34 + matrix1.M44 * matrix2.M44;
		}

		public static Matrix Multiply(Matrix matrix1, float factor)
		{
			matrix1.M11 *= factor;
			matrix1.M12 *= factor;
			matrix1.M13 *= factor;
			matrix1.M14 *= factor;
			matrix1.M21 *= factor;
			matrix1.M22 *= factor;
			matrix1.M23 *= factor;
			matrix1.M24 *= factor;
			matrix1.M31 *= factor;
			matrix1.M32 *= factor;
			matrix1.M33 *= factor;
			matrix1.M34 *= factor;
			matrix1.M41 *= factor;
			matrix1.M42 *= factor;
			matrix1.M43 *= factor;
			matrix1.M44 *= factor;
			return matrix1;
		}

		public static void Multiply(ref Matrix matrix1, float factor, out Matrix result)
		{
			result.M11 = matrix1.M11 * factor;
			result.M12 = matrix1.M12 * factor;
			result.M13 = matrix1.M13 * factor;
			result.M14 = matrix1.M14 * factor;
			result.M21 = matrix1.M21 * factor;
			result.M22 = matrix1.M22 * factor;
			result.M23 = matrix1.M23 * factor;
			result.M24 = matrix1.M24 * factor;
			result.M31 = matrix1.M31 * factor;
			result.M32 = matrix1.M32 * factor;
			result.M33 = matrix1.M33 * factor;
			result.M34 = matrix1.M34 * factor;
			result.M41 = matrix1.M41 * factor;
			result.M42 = matrix1.M42 * factor;
			result.M43 = matrix1.M43 * factor;
			result.M44 = matrix1.M44 * factor;
		}

		public static Matrix Negate(Matrix matrix)
		{
			Multiply(ref matrix, -1f, out matrix);
			return matrix;
		}

		public static void Negate(ref Matrix matrix, out Matrix result)
		{
			Multiply(ref matrix, -1f, out result);
		}

		public static Matrix Subtract(Matrix matrix1, Matrix matrix2)
		{
			matrix1.M11 -= matrix2.M11;
			matrix1.M12 -= matrix2.M12;
			matrix1.M13 -= matrix2.M13;
			matrix1.M14 -= matrix2.M14;
			matrix1.M21 -= matrix2.M21;
			matrix1.M22 -= matrix2.M22;
			matrix1.M23 -= matrix2.M23;
			matrix1.M24 -= matrix2.M24;
			matrix1.M31 -= matrix2.M31;
			matrix1.M32 -= matrix2.M32;
			matrix1.M33 -= matrix2.M33;
			matrix1.M34 -= matrix2.M34;
			matrix1.M41 -= matrix2.M41;
			matrix1.M42 -= matrix2.M42;
			matrix1.M43 -= matrix2.M43;
			matrix1.M44 -= matrix2.M44;
			return matrix1;
		}

		public static void Subtract(ref Matrix matrix1, ref Matrix matrix2, out Matrix result)
		{
			result.M11 = matrix1.M11 - matrix2.M11;
			result.M12 = matrix1.M12 - matrix2.M12;
			result.M13 = matrix1.M13 - matrix2.M13;
			result.M14 = matrix1.M14 - matrix2.M14;
			result.M21 = matrix1.M21 - matrix2.M21;
			result.M22 = matrix1.M22 - matrix2.M22;
			result.M23 = matrix1.M23 - matrix2.M23;
			result.M24 = matrix1.M24 - matrix2.M24;
			result.M31 = matrix1.M31 - matrix2.M31;
			result.M32 = matrix1.M32 - matrix2.M32;
			result.M33 = matrix1.M33 - matrix2.M33;
			result.M34 = matrix1.M34 - matrix2.M34;
			result.M41 = matrix1.M41 - matrix2.M41;
			result.M42 = matrix1.M42 - matrix2.M42;
			result.M43 = matrix1.M43 - matrix2.M43;
			result.M44 = matrix1.M44 - matrix2.M44;
		}

		public static Matrix Transpose(Matrix matrix)
		{
			Transpose(ref matrix, out var result);
			return result;
		}

		public static void Transpose(ref Matrix matrix, out Matrix result)
		{
			result.M11 = matrix.M11;
			result.M12 = matrix.M21;
			result.M13 = matrix.M31;
			result.M14 = matrix.M41;
			result.M21 = matrix.M12;
			result.M22 = matrix.M22;
			result.M23 = matrix.M32;
			result.M24 = matrix.M42;
			result.M31 = matrix.M13;
			result.M32 = matrix.M23;
			result.M33 = matrix.M33;
			result.M34 = matrix.M43;
			result.M41 = matrix.M14;
			result.M42 = matrix.M24;
			result.M43 = matrix.M34;
			result.M44 = matrix.M44;
		}

		public float Determinant()
		{
			float num = M31 * M42 - M32 * M41;
			float num2 = M31 * M43 - M33 * M41;
			float num3 = M31 * M44 - M34 * M41;
			float num4 = M32 * M43 - M33 * M42;
			float num5 = M32 * M44 - M34 * M42;
			float num6 = M33 * M44 - M34 * M43;
			return M11 * (M22 * num6 - M23 * num5 + M24 * num4) - M12 * (M21 * num6 - M23 * num3 + M24 * num2) + M13 * (M21 * num5 - M22 * num3 + M24 * num) - M14 * (M21 * num4 - M22 * num2 + M23 * num);
		}

		public bool Equals(Matrix other)
		{
			return this == other;
		}

		public static Matrix operator +(Matrix matrix1, Matrix matrix2)
		{
			Add(ref matrix1, ref matrix2, out matrix1);
			return matrix1;
		}

		public static Matrix operator /(Matrix matrix1, Matrix matrix2)
		{
			Divide(ref matrix1, ref matrix2, out var result);
			return result;
		}

		public static Matrix operator /(Matrix matrix1, float divider)
		{
			Divide(ref matrix1, divider, out var result);
			return result;
		}

		public static bool operator ==(Matrix matrix1, Matrix matrix2)
		{
			if (matrix1.M11 == matrix2.M11 && matrix1.M12 == matrix2.M12 && matrix1.M13 == matrix2.M13 && matrix1.M14 == matrix2.M14 && matrix1.M21 == matrix2.M21 && matrix1.M22 == matrix2.M22 && matrix1.M23 == matrix2.M23 && matrix1.M24 == matrix2.M24 && matrix1.M31 == matrix2.M31 && matrix1.M32 == matrix2.M32 && matrix1.M33 == matrix2.M33 && matrix1.M34 == matrix2.M34 && matrix1.M41 == matrix2.M41 && matrix1.M42 == matrix2.M42 && matrix1.M43 == matrix2.M43)
			{
				return matrix1.M44 == matrix2.M44;
			}
			return false;
		}

		public static bool operator !=(Matrix matrix1, Matrix matrix2)
		{
			return !(matrix1 == matrix2);
		}

		public static Matrix operator *(Matrix matrix1, Matrix matrix2)
		{
			Matrix result = default(Matrix);
			Multiply(ref matrix1, ref matrix2, out result);
			return result;
		}

		public static Matrix operator *(Matrix matrix, float scaleFactor)
		{
			Multiply(ref matrix, scaleFactor, out matrix);
			return matrix;
		}

		public static Matrix operator *(float scaleFactor, Matrix matrix)
		{
			Matrix result = default(Matrix);
			result.M11 = matrix.M11 * scaleFactor;
			result.M12 = matrix.M12 * scaleFactor;
			result.M13 = matrix.M13 * scaleFactor;
			result.M14 = matrix.M14 * scaleFactor;
			result.M21 = matrix.M21 * scaleFactor;
			result.M22 = matrix.M22 * scaleFactor;
			result.M23 = matrix.M23 * scaleFactor;
			result.M24 = matrix.M24 * scaleFactor;
			result.M31 = matrix.M31 * scaleFactor;
			result.M32 = matrix.M32 * scaleFactor;
			result.M33 = matrix.M33 * scaleFactor;
			result.M34 = matrix.M34 * scaleFactor;
			result.M41 = matrix.M41 * scaleFactor;
			result.M42 = matrix.M42 * scaleFactor;
			result.M43 = matrix.M43 * scaleFactor;
			result.M44 = matrix.M44 * scaleFactor;
			return result;
		}

		public static Matrix operator -(Matrix matrix1, Matrix matrix2)
		{
			Matrix result = default(Matrix);
			Subtract(ref matrix1, ref matrix2, out result);
			return result;
		}

		public static Matrix operator -(Matrix matrix1)
		{
			Negate(ref matrix1, out matrix1);
			return matrix1;
		}

		public override bool Equals(object obj)
		{
			return this == (Matrix)obj;
		}

		public override int GetHashCode()
		{
			throw new NotImplementedException();
		}

		public override string ToString()
		{
			return "{ {M11:" + M11 + " M12:" + M12 + " M13:" + M13 + " M14:" + M14 + "} {M21:" + M21 + " M22:" + M22 + " M23:" + M23 + " M24:" + M24 + "} {M31:" + M31 + " M32:" + M32 + " M33:" + M33 + " M34:" + M34 + "} {M41:" + M41 + " M42:" + M42 + " M43:" + M43 + " M44:" + M44 + "} }";
		}
	}
}
