namespace Microsoft.Xna.Framework
{
	public enum CurveTangent
	{
		Flat,
		Linear,
		Smooth
	}
}
