namespace Microsoft.Xna.Framework
{
	public enum CurveLoopType
	{
		Constant,
		Cycle,
		CycleOffset,
		Oscillate,
		Linear
	}
}
