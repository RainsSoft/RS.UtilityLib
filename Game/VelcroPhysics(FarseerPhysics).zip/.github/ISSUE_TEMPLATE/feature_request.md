---
name: Feature request
about: Suggest a feature for this project
title: ''
labels: enhancement
assignees: ''

---

* [ ] I hereby verify that I am a sponsor.
Sponsorship is required before you can submit feature requests. See https://github.com/sponsors/Genbox

**Describe the feature**
Provide a short description of the feature. Why would you like the feature?
If the feature makes changes to an existing or new API please provide an example.
