﻿using Microsoft.Xna.Framework;

namespace Genbox.VelcroPhysics.MonoGame.Content.SVGImport.Objects
{
    public class PathDefinition
    {
        public string Id;
        public string Path;
        public Matrix Transformation;
    }
}