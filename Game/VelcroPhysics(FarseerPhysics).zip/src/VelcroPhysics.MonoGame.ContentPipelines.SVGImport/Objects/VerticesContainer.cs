﻿using System.Collections.Generic;

namespace Genbox.VelcroPhysics.MonoGame.Content.SVGImport.Objects
{
    public class VerticesContainer : Dictionary<string, List<VerticesExt>> { }
}