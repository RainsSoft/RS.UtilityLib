﻿namespace Genbox.VelcroPhysics.Benchmarks.Code
{
    public class DummyStopWatch
    {
        public void Start()
        {
        }

        public long ElapsedMilliseconds => 0;

        public void Stop()
        {
        }
    }
}