﻿namespace Genbox.VelcroPhysics.Benchmarks.Code.TestClasses
{
    public struct Struct64
    {
        public Struct32 Value1;
        public Struct32 Value2;
    }
}