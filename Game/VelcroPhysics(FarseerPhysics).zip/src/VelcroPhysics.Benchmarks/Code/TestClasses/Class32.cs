﻿namespace Genbox.VelcroPhysics.Benchmarks.Code.TestClasses
{
    public class Class32
    {
        public Class8 Value1;
        public Class8 Value2;
        public Class8 Value3;
        public Class8 Value4;
    }
}