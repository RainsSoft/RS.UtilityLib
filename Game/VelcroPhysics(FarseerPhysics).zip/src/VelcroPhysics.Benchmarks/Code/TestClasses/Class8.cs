﻿namespace Genbox.VelcroPhysics.Benchmarks.Code.TestClasses
{
    public class Class8
    {
        public int Value1;
        public int Value2;
    }
}