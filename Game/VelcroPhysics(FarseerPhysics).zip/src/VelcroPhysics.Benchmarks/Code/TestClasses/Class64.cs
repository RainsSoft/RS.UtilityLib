﻿namespace Genbox.VelcroPhysics.Benchmarks.Code.TestClasses
{
    public class Class64
    {
        public Class32 Value1;
        public Class32 Value2;
    }
}