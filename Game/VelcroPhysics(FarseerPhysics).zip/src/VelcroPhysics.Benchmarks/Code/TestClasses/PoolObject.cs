﻿namespace Genbox.VelcroPhysics.Benchmarks.Code.TestClasses
{
    internal sealed class PoolObject 
    {
        public string TestString { get; set; }
        public int TestInteger { get; set; }

        public void Reset() { }
    }
}