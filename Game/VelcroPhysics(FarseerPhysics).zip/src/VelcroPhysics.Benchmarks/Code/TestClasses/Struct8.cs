﻿namespace Genbox.VelcroPhysics.Benchmarks.Code.TestClasses
{
    public struct Struct8
    {
        public int Value1;
        public int Value2;
    }
}