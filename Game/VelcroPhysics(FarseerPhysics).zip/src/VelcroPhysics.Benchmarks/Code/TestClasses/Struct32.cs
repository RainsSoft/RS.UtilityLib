﻿namespace Genbox.VelcroPhysics.Benchmarks.Code.TestClasses
{
    public struct Struct32
    {
        public Struct8 Value1;
        public Struct8 Value2;
        public Struct8 Value3;
        public Struct8 Value4;
    }
}