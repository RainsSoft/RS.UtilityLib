namespace Genbox.VelcroPhysics.MonoGame.Samples.Testbed.Framework.Input
{
    public enum MouseButton
    {
        Left,
        Right,
        Middle
    }
}