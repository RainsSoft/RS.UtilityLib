namespace Genbox.VelcroPhysics.Tools.Cutting.Simple
{
    internal enum PolyClipType
    {
        Intersect,
        Union,
        Difference
    }
}