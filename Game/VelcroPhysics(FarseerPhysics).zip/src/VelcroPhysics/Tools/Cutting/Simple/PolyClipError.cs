namespace Genbox.VelcroPhysics.Tools.Cutting.Simple
{
    public enum PolyClipError
    {
        None,
        DegeneratedOutput,
        NonSimpleInput,
        BrokenResult
    }
}