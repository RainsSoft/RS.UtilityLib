﻿using System;

namespace Genbox.VelcroPhysics.Shared.Contracts
{
    public class RequiredException : Exception
    {
        public RequiredException(string message) : base(message) { }
    }
}