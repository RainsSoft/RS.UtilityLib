﻿using System;

namespace Genbox.VelcroPhysics.Shared.Contracts
{
    public class EnsuresException : Exception
    {
        public EnsuresException(string message) : base(message) { }
    }
}