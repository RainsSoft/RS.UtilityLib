namespace Genbox.VelcroPhysics.Definitions
{
    public interface IDef
    {
        void SetDefaults();
    }
}