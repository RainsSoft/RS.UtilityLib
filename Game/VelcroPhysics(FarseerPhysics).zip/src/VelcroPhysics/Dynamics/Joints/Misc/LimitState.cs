namespace Genbox.VelcroPhysics.Dynamics.Joints.Misc
{
    public enum LimitState
    {
        Inactive,
        AtLower,
        AtUpper,
        Equal
    }
}