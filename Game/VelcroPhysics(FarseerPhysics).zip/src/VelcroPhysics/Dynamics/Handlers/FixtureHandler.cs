namespace Genbox.VelcroPhysics.Dynamics.Handlers
{
    public delegate void FixtureHandler(Fixture fixture);
}