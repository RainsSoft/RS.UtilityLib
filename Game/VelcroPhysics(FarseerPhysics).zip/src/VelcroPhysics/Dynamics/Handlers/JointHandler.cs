using Genbox.VelcroPhysics.Dynamics.Joints;

namespace Genbox.VelcroPhysics.Dynamics.Handlers
{
    public delegate void JointHandler(Joint joint);
}