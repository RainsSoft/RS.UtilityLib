using Genbox.VelcroPhysics.Extensions.Controllers.ControllerBase;

namespace Genbox.VelcroPhysics.Dynamics.Handlers
{
    public delegate void ControllerHandler(Controller controller);
}