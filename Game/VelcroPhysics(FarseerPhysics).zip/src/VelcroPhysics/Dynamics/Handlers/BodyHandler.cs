namespace Genbox.VelcroPhysics.Dynamics.Handlers
{
    public delegate void BodyHandler(Body body);
}