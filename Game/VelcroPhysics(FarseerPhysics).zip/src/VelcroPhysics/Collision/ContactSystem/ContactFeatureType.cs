namespace Genbox.VelcroPhysics.Collision.ContactSystem
{
    public enum ContactFeatureType : byte
    {
        Vertex = 0,
        Face = 1
    }
}