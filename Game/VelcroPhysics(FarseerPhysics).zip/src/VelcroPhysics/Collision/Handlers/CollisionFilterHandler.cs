using Genbox.VelcroPhysics.Dynamics;

namespace Genbox.VelcroPhysics.Collision.Handlers
{
    public delegate bool CollisionFilterHandler(Fixture fixtureA, Fixture fixtureB);
}