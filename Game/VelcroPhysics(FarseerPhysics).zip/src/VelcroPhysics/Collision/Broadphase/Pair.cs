namespace Genbox.VelcroPhysics.Collision.Broadphase
{
    internal struct Pair
    {
        public int ProxyIdA;
        public int ProxyIdB;
    }
}