namespace Genbox.VelcroPhysics.Collision.TOI
{
    public struct TOIOutput
    {
        public TOIOutputState State;
        public float T;
    }
}