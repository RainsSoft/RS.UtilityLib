﻿using System.Reflection;

[assembly: AssemblyVersion("$ASSEMBLY_VERSION$")]
[assembly: AssemblyFileVersion("$ASSEMBLY_FILE_VERSION$")]