---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Please explain the suggested feature in detail.**

**How exactly does this keep you from releasing your game right now?**

**Can you suggest a possible solution?**

**Additional context**
Add any other context or screenshots about the feature request here.
