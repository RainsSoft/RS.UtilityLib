namespace Mirror
{
    public interface NetworkMessage {}
}
