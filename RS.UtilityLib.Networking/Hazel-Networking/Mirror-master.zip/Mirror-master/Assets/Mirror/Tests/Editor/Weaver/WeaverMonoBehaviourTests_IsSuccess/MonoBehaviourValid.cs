using UnityEngine;

namespace WeaverMonoBehaviourTests.MonoBehaviourValid
{
    class MonoBehaviourValid : MonoBehaviour
    {
#pragma warning disable CS0414
        int monkeys = 12;
#pragma warning restore CS0414
    }
}
