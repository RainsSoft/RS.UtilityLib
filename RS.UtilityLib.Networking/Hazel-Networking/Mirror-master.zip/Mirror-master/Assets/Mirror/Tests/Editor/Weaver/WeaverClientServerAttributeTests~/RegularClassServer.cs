using Mirror;

namespace WeaverClientServerAttributeTests.RegularClassServer
{
    class RegularClassServer
    {
        [Server]
        void ServerOnlyMethod() { }
    }
}
