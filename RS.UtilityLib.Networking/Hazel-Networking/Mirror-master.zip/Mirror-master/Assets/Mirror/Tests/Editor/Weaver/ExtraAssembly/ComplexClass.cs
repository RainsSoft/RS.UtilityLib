namespace Mirror.Weaver.Tests.Extra
{
    public struct ComplexData
    {
        public AnotherData another;
        public float q;
    }
    public struct AnotherData
    {
        public float a;
        public float b;
        public float c;
    }
}
