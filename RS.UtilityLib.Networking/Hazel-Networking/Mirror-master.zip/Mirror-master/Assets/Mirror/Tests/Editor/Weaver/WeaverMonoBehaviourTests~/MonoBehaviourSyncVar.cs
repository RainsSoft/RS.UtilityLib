using Mirror;
using UnityEngine;

namespace WeaverMonoBehaviourTests.MonoBehaviourSyncVar
{
    class MonoBehaviourSyncVar : MonoBehaviour
    {
        [SyncVar]
        int potato;
    }
}
