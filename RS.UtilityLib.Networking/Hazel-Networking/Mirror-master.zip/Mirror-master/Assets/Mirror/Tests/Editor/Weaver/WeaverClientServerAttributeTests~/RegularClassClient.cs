using Mirror;

namespace WeaverClientServerAttributeTests.RegularClassClient
{
    class RegularClassClient
    {
        [Client]
        void ClientOnlyMethod() { }
    }
}
