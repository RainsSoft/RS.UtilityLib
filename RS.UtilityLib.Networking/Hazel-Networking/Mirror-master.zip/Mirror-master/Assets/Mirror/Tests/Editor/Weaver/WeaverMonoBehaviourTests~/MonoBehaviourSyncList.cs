using Mirror;
using UnityEngine;

namespace WeaverMonoBehaviourTests.MonoBehaviourSyncList
{
    class MonoBehaviourSyncList : MonoBehaviour
    {
        SyncList<int> potato;
    }
}
