﻿namespace Mirror.Weaver.Tests.Extra
{
    public class SomeDataClassWithConstructor
    {
        public int usefulNumber;

        public SomeDataClassWithConstructor()
        {
            // empty
        }
    }
}
