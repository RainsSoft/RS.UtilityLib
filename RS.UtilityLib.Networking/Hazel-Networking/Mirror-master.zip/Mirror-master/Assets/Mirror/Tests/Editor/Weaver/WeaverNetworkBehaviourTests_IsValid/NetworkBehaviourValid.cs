using Mirror;

namespace WeaverNetworkBehaviourTests.NetworkBehaviourValid
{
    class MirrorTestPlayer : NetworkBehaviour
    {
        [SyncVar]
        public int durpatron9000 = 12;
    }
}
